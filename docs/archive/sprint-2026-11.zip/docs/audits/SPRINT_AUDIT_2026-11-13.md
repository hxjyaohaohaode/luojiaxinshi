# 珞珈信使冲刺全量审查总账：候选冻结验证与首轮历史

文件标识日期为 2026-11-13；实际复核及运行记录为 **2026-11-14 UTC**。基线 `b362ab2100f835ace66bbc2b92921e865af1e1ce`。

**本总账覆盖原始 LJ-001—128，每条保留原文、优先级、证据和剩余条件；覆盖完整不等于验收全部完成。** 本文件及配套 JSON 保留 [PR #4](https://github.com/hxjyaohaohaode/luojiaxinshi/pull/4) 的首轮合并前工程验证，真实外部条件与 P2 继续单列。原 run52、`validated_code`、`current_*` 和旧门禁数据属于首轮历史，各自候选、性能及失败身份保持不变。

## 最新候选验证冻结：CI63

**冻结时间：2026-11-14T12:18:27.857754+00:00。** 候选 `70226e910b7fe2ecdfd49b0a34dcd62ba00484bc`，tree `894b7ef5b4c77da666177649e853afb0811f1359`，实际 PR 检出 `e3adde8146fec6fbb9f4f63057fabb97a6a8d975`。[CI63](https://github.com/hxjyaohaohaode/luojiaxinshi/actions/runs/43592108675) 已实际 **9／9 required jobs 成功**，原始 ZIP、分片 JUnit、日志、报告字段与截图复核完成。完整证据见 [CI63 冻结记录](sprint-review-ci-63-success.json)、[补修审计](SPRINT_REVIEW_FOLLOWUP_2026-11-14.md) 与 [机器证据](sprint-review-followup.json)。此处记录的是合并前候选；最终 main 提交及 main 自身 push CI 由 [PR #5 最终交付记录](https://github.com/hxjyaohaohaode/luojiaxinshi/pull/5) 和 [Actions](https://github.com/hxjyaohaohaode/luojiaxinshi/actions) 核实，不在预合并文档中编入未来 SHA。

| 本次原始验证范围 | 实际结果与边界 |
|---|---|
| Ubuntu 后端 | 139 个唯一文件、1,875 个唯一用例：1,873 通过、2 个 Windows 专属 guard 明确跳过，0 failure／error。固定版本 Office parser 和原 `<15 SELECT` 门槛实际通过。 |
| Windows 后端 | 四片原始并集与汇总逐项一致：139 个唯一文件、1,875 个唯一用例，1,874 通过、1 项 POSIX TIME_WAIT 语义跳过，0 failure／error。全部原有身份保留。 |
| Node／构建／审计 | 两 OS 各 358／358，不相加成 716 个场景；可复现构建 `app-EXBTH7EL`／`styles-BHHEBXRE`，25 产物、194 来源；完整 npm 范围及严格 Python 审计均通过。各 OS 指纹单独保留，以同一实际 checkout 绑定。 |
| 正式浏览器 | 33／33 报告、1,056／1,056 检查通过；Sprint 78、看板 28。保留各报告实际引擎，Agent／Composer 只在 Chromium 执行，不泛称全部三引擎。 |
| 连续保存／恢复 | 990／990，Chromium／Firefox／WebKit 各 330；合成数据，不代替真实使用天数。 |
| 交互与视觉复核 | 看板 18 个阶段观测不是新增业务用例；真实首次入场结束后，拖放释放、POST 应用收尾与逐帧均无入场重放。认证真实 401→同文档登录→旧提示清除、三张 390×844 手机图自然关闭抽屉、Composer 三份录音几何与实际图均复核。 |

### 逐项覆盖和未解除的条件

原始 **128 项＝118 项 P1＋2 项条件 P0（LJ-010／031）＋8 项条件 P2**。128 项都有原文、编号、来源行、优先级和证据；这不是“128 项全部实地验收通过”。**51 项含真实外部验收条件**，它们与已实现代码及定向证据重叠，不能再当作独立 51 个功能，也不能从工程通过中消去。八项 P2（LJ-007／008／021／022／056／064／065／110）仍是条件扩展；根 LICENSE 选择、真实供应商／设备／人员、独立人工标注、至少五天实践及院方范围确认继续保留。前端 25 项与 209 项参考映射保持原始清单，209 项不等于安装 209 个依赖。

最新独立本地性能记录的实际身份仍是 `9e86`／`81f4…`：5 人 766 HTTP、625 个正常 CRUD 样本，总写等待 P95 **85.079 ms（776 样本，仅单次通过）**，CRUD P95 196.4 ms；10 人 1,531 HTTP、1,250 CRUD 样本，总等待 **172.555 ms（1,590 样本，未达到原 `<100 ms`）**，CRUD P95 471.2 ms。后端／schema／依赖／运行时／容量输入与本候选逐 blob 对齐；workflow 仅补两条诊断文件上传路径，执行及门禁未变，但不能称 workflow 字节相同。适用性证明见机器补修总账，**没有把旧本地观察改成新一轮运行**。本地 1 万通知的 50 项普通页面最大 106,666 B，冷读 41.74 ms，5 次热读 P50／P95 35.89／49.85 ms。CI 共享 runner 单次性能、目标部署容量和学校批准分别保留。

本轮恢复证据只证明已完成写入后制作的合成快照中任务身份及业务字段相等，编辑缓存只核版本；取消记录仅在该快照已经包含时保留，不构成断电演练或任意历史快照的 RPO 保证。未知外部服务不称已接通，未知预算不自动批量调用，十人扩大门槛未获解除。

### 保持原方向的主要增强

| 范围 | 有实现证据的增强与边界 | 可追溯入口 |
|---|---|---|
| 来源和批次 | 受信 Feed 与原发布单位分开、规则试读／应用／回滚、HTTP 缓存协议与域名公平、同 URL 跨年度批次隔离；私有来源不跨账户复用。 | [来源证据](sprint-sources-evidence.md)、[source_fetch.py](../../app/source_fetch.py)、[notice_ingest.py](../../app/notice_ingest.py) |
| 通知生命周期与办理 | 未公告、公示异议、结果及后续动作使用持久记录和版本证据；正式期限、个人计划、材料及提交回执分开，旧报名结束不吞新结果。 | [notice_tracking.py](../../app/notice_tracking.py)、[workflow.py](../../app/workflow.py)、[task_materials.py](../../app/task_materials.py) |
| 学院发布和恢复 | 实际角色／范围复核、不可变原件、同 ID 原内容重试、持久停止未完成提交、跨学院最小本人回执、缺件名称保留但不冒充上传完成。 | [campus.py](../../app/campus.py)、[campus_submissions.py](../../app/campus_submissions.py)、[campus_drafts.py](../../app/campus_drafts.py) |
| 提醒与发送 | 统一事件和偏好、静默／摘要／过期、发送前撤权复核、收件更正分类、邮件额度与 claim 同事务；供应商接受不冒充设备已展示或已读。 | [notification_events.py](../../app/notification_events.py)、[mail_delivery.py](../../app/mail_delivery.py)、[push_delivery.py](../../app/push_delivery.py) |
| 大量记录与实时一致性 | 轻量分页／FTS、按完整看板顺序分页、保留加载范围和用户更多意图、离开列表时失效、强制刷新不复用旧 mutation 前请求、分钟无变化不读全页。 | [listing.py](../../app/listing.py)、[workspace_projection.py](../../app/workspace_projection.py)、[paged-list.js](../../static/paged-list.js) |
| 前端真实交互 | 保持珞珈绿与现有导航，拆分加载和内容哈希构建；清晰下一步、键盘／触控替代、首次协作／记忆入口、登录提示生命周期、手机抽屉和录音控件裁剪修正。 | [前端审计](../sprint-2026-11-14/FRONTEND_AUDIT.md)、[auth.js](../../static/auth.js)、[chat-refinements.css](../../static/system/chat-refinements.css) |
| AI 与记忆边界 | 保留并审查来源只是数据、工具 owner／scope／批准门禁、事实／未知条件分开，以及来源可追溯／纠正／遗忘；真实模型和人工冻结标签仍待实际评价。 | [来源／AI 审计](sprint-sources-evidence.md)、[agent_runtime/tools.py](../../app/agent_runtime/tools.py)、[memory_lifecycle.py](../../app/memory_lifecycle.py) |
| 运维、隐私和恢复 | 独立管理员事件、确认／恢复／复发、配置与真实接通分开、schema／备份验证、恢复旧外发授权清理、严格依赖和可复现构建；不擅选项目许可证。 | [OPERATIONS.md](../../OPERATIONS.md)、[PILOT_RELEASE_GATES.md](../PILOT_RELEASE_GATES.md)、[backups.py](../../app/backups.py) |

### 后续历轮记录继续保留

| 历史轮次 | 原始结果，不用当前通过改写 |
|---|---|
| [CI59](sprint-review-ci-59-failure.json)／[CI60](sprint-review-ci-60-failure.json) | 各 1,053 项记录、1,050 通过、3 显式失败，末尾 3 项未执行；跨路由夹具用相同正文得到同一通知，删除级联任务，后经真实 API 独立复现并修正独立种子。其他通过门禁仍按原范围保留。 |
| [CI61](sprint-review-ci-61-functional-success.json) | 全部自动门禁成功，但手机旧认证提示和录音截图仍有视觉疑点；不能回写成当时已获最终视觉批准。 |
| [CI62](sprint-review-ci-62-failure.json) | 1,047 项已记录、1,046 通过、1 项看板 false；另有 Composer 日志 fatal，9 个正式检查未持久化报告，不能说全部未执行或推算其中通过数。真实 51 px 结构滚动已由本候选修复并重新取证。 |

以下是原 CI59 开始时的进度快照及更早首轮总账；“当前／最新”若位于历史段落，仅指该记录时点。JSON 除 `latest_followup` 及追加历史外的原有对象、128 项数组、来源行与原数值均逐字节保留。

## 历史进度快照：CI59 开始时

**该时点审查补修入口：** [补修审计记录](SPRINT_REVIEW_FOLLOWUP_2026-11-14.md)、[机器可读补修证据](sprint-review-followup.json) 与 [PR #5](https://github.com/hxjyaohaohaode/luojiaxinshi/pull/5)。新候选为 `6701b6534331b9dddd64bdd67a38ac2e524681a9`，tree `2cc780721a3a53acbe5440718b2862e87d809152`；[run59](https://github.com/hxjyaohaohaode/luojiaxinshi/actions/runs/43583884442) 在该历史记录时点为 **in_progress，尚未取得整轮结果**。139 文件／1,875 后端／341 Node 是本轮待原始 collection 核实的预期，原 329 Node 标识及新增 12 项也须实际逐项核对。移动／撤销保留已加载范围、在飞“加载更多”被后续稳定刷新接管，以及真实 54→查询重建 50→再次 54 的浏览器合同，均待本轮验证，不能用定向通过代替。

CI59 当时与 `9e86` 的差异精确限定为 8 个前端产品／构建／测试路径，其余 866 个路径逐 blob 相同。后端、schema、依赖、运行时及容量脚本未改变，因此旧本地观察继续具有关联性；其实际身份仍为 `9e86`／`81f4…`，**没有声称重跑出新的本地性能数值**。适用性原件为 `artifacts/sprint-review-followup/frontend-runtime-applicability-6701.json`，SHA-256 `271f584acd0dd2e11d49147527d686a76aa01d8796b2eec151f24fbb45c9d6c5`。

CI59 开始时最近完成的历史候选为 `9e86a1e9b798071e870a0e35d73b46610d435988`，tree `849605264ce3af3bffd15896f7a530b3685438af`，实际检出 `a39babb0406615384323b3ae346ca722a8253f3d`；[run58](https://github.com/hxjyaohaohaode/luojiaxinshi/actions/runs/43581184272) 官方结论为 **completed / failure，不能据此合并**。后续“加载更多”意图与刷新交错的修复仍待整合候选及新完整 CI。

| run58 实际范围 | 原始结果与剩余限制 |
|---|---|
| 主浏览器 | 33 个报告槽：32 通过、Sprint 1 个不完整。实际记录 **1,001 项：998 通过、3 项 false**；没有额外未记录 fatal。预期 1,056 项中有 **55 项未执行**，不能记为通过。 |
| Sprint | 78 项预期中记录 23 项：20 通过、3 失败。Chromium 的真实移动后首页响应 50 项且移动卡片位于第 49 位已通过；DOM 保留 54 项并精确完成相邻交换，随后“DOM 必须恰好 50”的夹具前提冲突。Firefox／WebKit 在下一项“加载更多至 54”等待失败；独立真实控制器已复现后台稳定刷新抢占在飞 append、丢失用户范围的缺陷，但原 CI 未记录内部 generation，不能把具体内部时序当成已直接观测。 |
| Ubuntu 后端与 Node | **139 个唯一文件、1,875 个唯一用例：1,873 通过、2 个 Windows 专属 guard 跳过，0 failure／error；Node 329／329。** 固定版本 Office 解析器真实用例通过。 |
| Windows 后端与 Node | **139 个唯一文件、1,875 个唯一用例：1,874 通过、1 项 POSIX TIME_WAIT 语义跳过，0 failure／error；Node 329／329。** 四个分片原始用例并集与汇总逐项一致；原 1,853 后端／302 Node 标识全部保留，新增 22／27。 |
| 本地同源码完整轮 | 新增 **1 个**整合全量轮：1,872 通过、3 项明确环境／平台跳过；Node 329／329。原 1,853／302 标识完整保留。不同平台、前后轮及定向套件不累加为更多唯一用例。 |

run58 完整浏览器核对原件为 `ci-evidence/43581184272/browser-report-audit.json`，SHA-256 `a659fe1987f3ba444f5bf9af87b611e3885104aa5b137042058facc58e1ec8e2`；Windows 原件核验为 `artifacts/ci-readonly/run-43581184272-windows-verification.json`，SHA-256 `fa414e645b07d5f69cdcf063d863279c7406841776465be86abbb9c4f3c47517`。[run58 完整失败档案](sprint-review-ci-58-failure.json) 保留原始摘要；33 份 early／final 报告逐字节相同。两平台实际检出相同，但 OS 字节指纹分别记录，不能声称跨平台指纹相同。构建、全范围 npm 审计与严格 Python 锁定依赖审计的通过，均只属于其实际执行范围。

**CI58 时点性能观察（历史，未解除工程限制）。** 本地同源码 5 人／766 HTTP 的总写等待 P95 为 **85.079 ms（776 样本，仅此单次通过）**；10 人／1,531 HTTP 为 **172.555 ms（1,590 样本，未达到 `<100 ms`）**，对应普通 CRUD P95 为 196.4／471.2 ms。CI Ubuntu／Windows 的 5 人共享 runner 单轮观察分别为 38.658／**111.719 ms**；Windows 本次也未达到原目标，不能用另一环境的成功覆盖。本地 1 万通知普通 50 项页面最大 106,666 B，冷读 41.74 ms，5 次热读 P50／P95 为 35.89／49.85 ms。以上都是合成、隔离工程观察，不是生产容量或学校验收；旧性能失败完整保留。重启／恢复验证范围是已完成所有业务写入的快照中的任务身份与业务内容相等，编辑缓存只核版本，既不是断电测试也不是任意历史快照的 RPO 保证。

前一历史候选为 `19d9162fc9395f9c140ca13545f5975e9d74ea81`，tree `5a5a6882c21dfb1141761bfe2897480febb66336`，实际检出 `568111d44b83baecf2f0a5683914294604713fd3`；[run57](https://github.com/hxjyaohaohaode/luojiaxinshi/actions/runs/43578124182) 已结束并失败，不能据此合并。

| run57 实际范围 | 原始结果与未完成部分 |
|---|---|
| 主浏览器汇总 | 33 个报告槽：31 通过、1 不完整、1 失败。实际记录 1,012 项，其中 1,010 通过、2 项为 false；另有 1 个未写入 checks 的聊天 fatal 断言。预期 1,053 项中，41 项没有完整记录，精确分为 **40 项未执行、1 项部分中止**。 |
| Sprint | 39 项有记录：37 通过、Chromium／Firefox 各 1 项失败；后续 36 项未执行。失败是等待第二页加载后 54 张卡片及 `aria-busy=false` 超时；原失败报告未保存这两引擎的完整请求链，不能单凭该报告断言准确请求时序。后续真实控制器回归独立复现了“加载更多”意图丢失和临时绘制门禁问题。 |
| WebKit 聊天交互 | 3 项完成后，第 4 项流式字符断言中止，后续 4 项未执行。未写入 checks 的 fatal 不能冒充第 4 项通过，也不能与两条显式 false 重复计数。当时待新 CI 的夹具在 run58 中已按各报告引擎实际通过；run57 原失败仍保留。 |
| Windows | 138 个唯一文件、1,853 个唯一后端用例：1,852 通过、1 项 POSIX 平台跳过、0 failure／error；Node 302／302。该平台的通过与浏览器失败分别保留，不等于整轮通过。 |

浏览器原始核对文件为 `ci-evidence/43578124182/browser-report-audit.json`，SHA-256 `05079684067715f0c4e50b1cd89ac7c0fbb34a380d3f9e241009f3c43f78a004`；具体失败及计数边界同步保存在两份总账 JSON 的 `latest_followup_history`。[run55 原失败记录](sprint-review-ci-55-failure.json)、[run56 原失败记录](sprint-review-ci-56-failure.json)、[run57 原失败记录](sprint-review-ci-57-failure.json) 和配套 JSON 的 `latest_followup_history` 保持原样，旧数据不改写为新候选结果。

**该历史时点的定向结果与门槛分别保留。** run58 开始前的定向 49／49、Node 329／329、mail 28／28 和 109／109 属于各自修复证据，存在重复覆盖，不能相加。139 文件／1,875 后端／329 Node 已由 run58 真实 collection 核实；新发现的反向范围竞态及移动后范围合同仍须在修复整合后的新 CI 验证。外部来源、供应商、人员、设备、人工标注及性能限制不因这些工程结果自动解除。原 128 条、51 项真实外部条件、8 项 P2 保持原样；最终 main 合并及 main 自身 Actions 由最新 PR 合并记录与 [Actions](https://github.com/hxjyaohaohaode/luojiaxinshi/actions) 另行核实。

## 1. 方向与判定原则

产品目标保持为校园通知、原件和个人条件，经核实转为本人下一步、材料、办理记录、日历与提醒。发布方正式事实、平台处理、本人进度及渠道回执分别保留。继续使用 FastAPI、SQLite、原生前端与珞珈绿／白底，不用新页面或独立假状态代替既有业务。

本轮按来源、工作流、校园和前端分域执行，反复回查正式依据、owner／版本、既有记录和本人外发同意。复核时发现的缓存策略、群内短消息候选、首页分钟全量读取、运维闭环和首次引导缺口已单独回传主执行者，逐项修复再冻结。

| 状态 | 严格含义 |
|---|---|
| 实现证据 | 存在且已核对对应源码或明确边界，不等于所有条件已满足。 |
| 已执行定向验证 | 对应测试文件在记录的定向运行范围内；逐条限制仍有效，不能推断全部断言涵盖每一自然语言要求。 |
| 候选工程门禁 | run52 9/9 jobs实际成功；只表示冻结候选既有实现的工程门禁通过，不构成128项自然语言要求的全部真实外部验收。 |
| 真实外部验收 | 需要真实供应商、来源、设备、人员、标注或目标部署条件，当前仍待。 |
| 条件扩展 | 原清单 P2：需求／平台授权条件未确立；不冒充已经实现。 |

原清单准确计数：128 项，P1 118 项、条件 P0 2 项（LJ-010／031）、P2 8 项（LJ-007／008／021／022／056／064／065／110）。不设置“完成百分比”，避免把不同层级证据混为 100%。

## 2. 原始要求与证据来源

原文逐行提取与附件哈希见 [requirements-extracted.json](../sprint-2026-11-14/requirements-extracted.json)；机器可读的完整总账为 [sprint-requirements-128.json](sprint-requirements-128.json)。本文件每条表格与 JSON 具有相同编号。

- 来源、生命周期、AI／记忆边界：[sprint-sources-evidence.md](sprint-sources-evidence.md)。
- 校园发布、组织、协作：[sprint-campus-evidence.md](sprint-campus-evidence.md)。
- 前端 25 项：[FRONTEND_AUDIT.md](../sprint-2026-11-14/FRONTEND_AUDIT.md)、[frontend-25.json](../sprint-2026-11-14/frontend-25.json)。
- 209 项组件采用：[components-209.json](../sprint-2026-11-14/components-209.json)；实际源码／交互核查：[reference-source-review.json](../sprint-2026-11-14/reference-source-review.json)。

最初资料复核确认：赛事项目目标是有依据的校园通知转办；真实实践至少五天、需求方配合及单位确认属于外部验收。资料中没有证明学校已经开放教务 SSO、全量公众号或微信群 API。昨日失败对话的直接记录不可访问时，不能伪造“已查到昨天全部改动”；仓库基线与本轮实际差异独立核实。

## 3. 首轮历史：合并前候选的冻结工程验证

候选 **6b15c7452966e7600cca87acf36a2e11ad034fbc**，tree **445d4ce97ecd9a8cbc10c88b78fb01c41bca4959**，Linux 全代码指纹 **a8173b44887b2a4e7aaea494777598105ca12ccafc28c29db17557d500b12f70**。[run52／43567666000](https://github.com/hxjyaohaohaode/luojiaxinshi/actions/runs/43567666000) 官方 completed/success，**9/9 jobs成功**。实际PR合并测试提交为 **ac3e291285b55c0dc28e4acd5f2673ddf29dca22**。这些是合并前候选工程证据，最终 main 身份另由PR与Actions核实。

**本地执行身份保持：** round4／5、runtime-v3与容量实际属于 **05498ae154403c239ee4efddca0041fd530ce6c3／d55ba13592713d9de75a6e2344cb0d2092f2302896cc895d15544fc25f603c12**。至6b15的非文档差异恰为两份浏览器夹具：scripts/verify_pilot_workspace.mjs、scripts/verify_sprint_ui.mjs；产品、静态构建、依赖、后端／Node测试与本地验证脚本逐路径未变。不将原报告指纹重写为新提交实跑；当前提交另有完整CI。见[sprint-validation.json](sprint-validation.json)的local_evidence_applicability。

| 实际记录 | 范围与结果 | 边界 |
|---|---|---|
| 本地 round4，05498ae/d55 | 134文件、1,792项：1,789 passed／3 skipped／0 failure／0 error；391.47秒 | 运行期间指纹未变；同一清单两轮不相加为不同测试 |
| 本地 round5，05498ae/d55 | 134文件、1,792项：1,789 passed／3 skipped／0 failure／0 error；404.83秒 | 运行期间指纹未变；同一清单两轮不相加为不同测试 |
| 本地前端及本轮重建 | Node 275／275；本地bundle／audit定向23／23；两平台build:check通过 | app-DFTX33VB／styles-BKR4PFDD，见[构建记录](../sprint-2026-11-14/frontend-build-verification.json) |
| run52 Ubuntu | 134唯一文件、1,792唯一JUnit：**1,790 passed／2 skipped／0 failure／0 error**；475.06秒；Node275／275 | 原查询<15、看板逆序、真实pinned parser均通过；全依赖审计与后续门禁success；Windows为最长分片耗时 |
| run52 Windows | 134唯一文件、1,792唯一JUnit：**1,791 passed／1 skipped／0 failure／0 error**；989.59秒；Node275／275 | 原查询<15、看板逆序、真实pinned parser均通过；全依赖审计与后续门禁success；Windows为最长分片耗时 |
| run52 连续保存／恢复 | **990／990**，失败／错误0；612＋204＋174 | Chromium／Firefox／WebKit各330，合成数据 |
| run52 主浏览器 | **33／33报告槽、1,038／1,038实际检查通过**，缺报告和漏记前轮通过项均0 | 各套件引擎按原始清单；Agent／Composer仅Chromium，不能泛称全部三引擎 |
| run52 容器与运行时 | 构建、健康、非root、数据库与界面资源、两OS真实HTTP重启／恢复门禁通过 | 实际合成数据，不能代替真实供应商、人员或目标部署性能 |

本地三个skip为缺可选pinned Tika/JRE、两项Windows process/socket guards；本轮Ubuntu真实执行parser，仅跳过两项Windows专属。Windows唯一skip为POSIX TIME_WAIT语义，四片447／480／389／476的真实JUnit完整聚合。Windows指纹 **01168269130fa0b0bd0fe577e05b394c292ccd59322a9234adea0100049e8439**，各片内部unchanged；两平台以同一实际checkout绑定，不声称跨OS字节指纹相同或猜测唯一差异原因。

Sprint **60／60**、Pilot **33／33**，含三引擎共6项协作冷入口关闭／换路由检查。三引擎均确认旧查询进入真实handler且读取200后尝试迟到放行，最新筛选保持：Chromium／WebKit取消旧请求，Firefox实际观察旧响应晚到，不伪写为三个引擎都接收旧响应。移动发布按钮普通滚动后实测44px且位于固定导航上方。受控网络夹具明确block Service Worker；独立真实worker安装、账户绑定与显式启用8项保留，不能把它称为真实设备推送或离线回退全部验收。

### 历史失败与定向修复记录

最初基线完整后端为 1,641 项；本轮首次完整尝试实有 **1 项失败**（133 文件、1,779 项：1,775 passed／3 skipped／1 failed）：新阶段元数据令 100 条通知搜索达到 15 SELECT，违反原 `<15` 门槛。原样复现后合并 owner／版本限定批量查询，实测降至 14，原门槛不变；5 文件定向 45 passed／28.82 秒。[查询回归记录](sprint-query-regression.json) 保留前后事实；后来的双轮与 Ubuntu 通过没有抹去首次失败。

首轮远程 CI 还暴露看板实际排序不一致、重复 DOM 绘制，以及验证脚本的旧接口、菜单交互和异步等待问题；逐组原因、原始计数、修复文件与待新 CI 边界见 [sprint-ci-first-round.json](sprint-ci-first-round.json)。源码缺陷与测试 fixture 变化分别记录。

| 较早记录（历史，非最终全套） | 已发生结果 |
|---|---|
| 来源／生命周期 11 文件 | 109 passed，1 TestClient 弃用告警，59.85 秒；含缓存策略，早于 LJ-019 新邻近候选 |
| 缓存协议专项 | 新策略 23 项＋旧来源合同 11 项＝34 passed；与 109 项有重叠，不累加 |
| 校园域 | 54 passed／87.48 秒，名称更正新增 1 项另跑 3.23 秒；两份 Node 另 6 passed |
| 较早前端 Node | **270／270 是历史数量**；首轮候选最终数量为上表 275／275 |
| 工作区投影最后定向 | 14 passed／39.79 秒；随后进入首轮完整后端双轮 |
| 群内邻近候选 | 41 passed／35.28 秒，含新增 6 场景；真实 QQ 平台仍未验收 |
| 看板排序定向 | board／listing／projection 26／26，JUnit 21.621 秒；故意使 legacy updated 顺序反转，原文与权限断言保留 |


[第二轮 run50 历史](sprint-ci-second-round.json) 保留 pilot 协作冷入口的真实产品缺陷、同类记忆冷入口修复，以及 sprint／composer 失败和未完整报告。[第三轮 run51 历史](sprint-ci-third-round.json) 已收齐：pilot 三引擎关闭选择器同时命中“关闭”和“返回”；sprint 的 Chromium／WebKit 旧查询捕获超时，Firefox 20 项全过。WebKit 同一查询实际 200，但旧报告缺 handler 进入和 worker 来源字段，不能宣称已证明 SW 缓存私人 API。新夹具唯一化关闭按钮、隔离 Service Worker 并增加诊断，原业务断言与超时保留；**修正后的受控流程已在run52实际通过；旧因果证据不足仍如实保留**。旧 round2／3、app-XK3PQMAE 及 33fca 测量保存在 JSON 历史和[旧候选记录](sprint-validation-before-cold-entry-fixes.json)。

### 首轮历史独立本地性能：v3 两档总等待均未达标

实际 05498ae/d55、独立本地真实 HTTP、合成账号和文本通知；功能断言与工程性能分开，不代表生产容量或院方批准。

| 负载档与 UTC 时间 | 数据和 HTTP 请求 | 非 AI 正常 CRUD P95 | 总写入等待 P95 | 工程门槛 |
|---|---|---|---|---|
| 5 人，06:16:29 | 100 通知、200 任务、**766 请求**；625 CRUD 样本 | **282.6 ms** | **114.149 ms**；778 等待样本 | CRUD <1s、零获取失败通过；**总等待未达 <100ms，不批准试点或扩大** |
| 10 人，06:17:38 | 200 通知、400 任务、**1,531 请求**；1,250 CRUD 样本 | **743.1 ms** | **272.906 ms**；1,629 等待样本 | CRUD <1s、零获取失败通过；**总等待未达 <100ms，不批准试点或扩大** |

总等待包括公平准入排队、连接准备和 SQLite BEGIN IMMEDIATE。5 人的预期 401／404／409 为 5／10／100，10 人为 10／20／200，验证鉴权、越权与 stale 拒绝，不混入正常 CRUD；登录、AI 另列，百分位使用 nearest-rank。共享 CI 单轮与独立本地结果分开，不能择优把 5 人称为稳定达标。

5 人备份／重启验证／恢复文件／恢复验证为 **0.041／2.001／0.098／2.512 秒**。
10 人备份／重启验证／恢复文件／恢复验证为 **0.041／2.027／0.089／3.275 秒**。

逐任务 ID 的 notice_id、status、version、data 与快照相等，合成快照范围丢失 0；旧会话拒绝、owner 隔离、stale 和幂等均过。写入完成后快照，SIGTERM 停止本人进程、超时才 SIGKILL；不是断电实验或生产 RPO。

### 首轮历史 1 万条容量与检索

第 10,000 条可保存，第 10,001 条新记录拒绝，同文幂等重放可用。旧全量响应 **20,992,851 B**，50 条轻量分页 **106,672 B**。每类 1 冷＋5 热，热样本 nearest-rank P95 为五者最大值。

| 查询 | 冷 ms | 热 P50 ms | 热 P95 ms | 最大响应 B |
|---|---:|---:|---:|---:|
| 收件时间分页 50 条 | 41.02 | 33.53 | 34.23 | 106,672 |
| 当前语义分页 | 481.08 | 46.33 | 79.05 | 106,705 |
| 正文全文索引单命中 | 101.99 | 70.82 | 156.68 | 3,070 |
| 短中文查询 | 115.23 | 104.16 | 109.32 | 111,959 |

完整数据见 [sprint-validation.json](sprint-validation.json)，脚本为 [verify_campus_capacity.py](../../scripts/verify_campus_capacity.py)。**历史保留：** 更早 765 请求／105,304 B 分页，33fca 候选 5 人总等待 88.957 ms／10 人 178.891 ms／106,675 B 分页，均在 JSON 历史；不代替该首轮历史 v3。[写入等待过程证据](sprint-write-wait-evidence.json) 保留失败和未采用实验，100 ms 原标准不变。

### 真实外部证据与保留条件

应用生产 reader 本环境只读尝试三个现有官网预设，因公共 DNS 解析失败停在列表阶段，没有完成正文／附件实网链。独立网页可读部分官网不代替应用端到端，见[来源采样](sprint-public-source-sample.json)。没有真实 QQ／公众号联调通过、没有外发同学老师消息、没有付费模型调用或伪造人工标准。

实体 Android／iOS／桌面、中文软键盘、读屏、200% 缩放、真实供应商、不少于 5 天校园实践及需求方确认仍需实证。**51 项外部条件与 8 项 P2 原样保留。** 本地双轮、合成 CI 及源码不能替代这些条件。run51 失败和当时未执行案例保留可审阅，run52工程门禁已通过；main最终身份由PR／Actions核实。

## 4. 128 项逐项总账

### A. 账号、身份与组织：LJ-001—010

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-001／P1 | 首次到达说明“现在能用什么”。普通个人账号可先收件办理，学院身份单独显示待核实；可选引导能跳过并找回。 | 新增首页“现在能用什么”三步说明，可跳过且持久保存于本人 profile，设置页可重新打开；说明个人收件不等待学院核实，自填教师／系统管理员不获得学院发布身份。失败保留说明与输入，账号／路由回包有守卫。 | 实现证据／已执行定向验证；[getting-started.js](../../static/getting-started.js)；[getting-started.css](../../static/system/getting-started.css)；[getting-started.test.mjs](../../tests/getting-started.test.mjs)；[work-context.test.mjs](../../tests/work-context.test.mjs) | 首次引导、跳过后找回与按账号持久保存已在 run52 Sprint 三引擎实际通过；结论限合成账号和已执行场景。 |
| LJ-002／P1 | 注册、验证码、找回密码真实供应商联调。错码/旧码/限流/延迟/重复点击有恢复路径，不能把供应商接受写成本人已收到。 | 验证码挑战、限流、单次校验、找回密码及供应商适配已有服务端合同；前端按实际挑战与失败回执恢复，不把供应商受理说成本人收到了。 | 实现证据／已执行定向验证／真实外部验收；[verification.py](../../app/verification.py)；[cloud_messages.py](../../app/cloud_messages.py)；[test_verification.py](../../tests/test_verification.py)；[test_verification_evidence.py](../../tests/test_verification_evidence.py) | 真实邮件／短信供应商凭据、网络、配额及手机收码联调没有本轮通过证据；须覆盖旧码、错码、延迟、重复点击和真实收件。 |
| LJ-003／P1 | 统一自填身份、已核实学院身份、系统管理身份的标签。自选教师不解锁发布，直接链接无权时不泄露内容。 | 自填个人资料与当前校园成员授权分别读取；页面可用工作身份由服务端权限决定，学院发布与跨院读取仍有后端拒绝。 | 实现证据／已执行定向验证／真实外部验收；[work-context.js](../../static/work-context.js)；[app.js](../../static/app.js)；[work-context.test.mjs](../../tests/work-context.test.mjs)；[test_campus_permissions.py](../../tests/test_campus_permissions.py) | 实际学院身份确认需要有权管理者核验；自选教师不是正式任职证明。 |
| LJ-004／P1 | 学院、年级、班级规范化和迁移预览。处理“2026/2026级/一年级”、同名班、空值和历史名称；迁移前后收件对象可核对。 | `campus_roster.py`提供NFKC和空白规范化，`2026`转为`2026级`，对`一年级`提示而不猜。预览显示原身份、规范后身份和已有正式受众的增减账号。`campus-roster.js`提供表格、CSV、JSON录入及逐行核对。 | 实现证据／已执行定向验证／真实外部验收；[campus_roster.py](../../app/campus_roster.py)；[campus-roster.js](../../static/campus-roster.js)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 现有授权仍按明确年级／班级范围；旧发布范围不会被名称迁移隐式扩大。院方需确认模糊历史名称对应哪一届。 |
| LJ-005／P1 | 组织成员批量导入先预检再提交：重复账号、未注册、冲突班级、越权范围逐项说明；重放不重复授权。 | 最多500行；重复、未注册、无效字段、角色和跨院越权逐行报告；只提交明确选中的有效行。预检绑定目标及操作者授权，10分钟有效，原预检重放幂等。 | 实现证据／已执行定向验证；[campus_roster.py](../../app/campus_roster.py)；[campus-roster.js](../../static/campus-roster.js)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 账号注册和真实身份核验仍由现有注册流程、管理者完成；不伪造学籍验证。 |
| LJ-006／P1 | 撤权、转班、离院、毕业与离任交接贯通。新权限即时生效；本人旧记录、旧事项后续更正和私密新内容有明确边界。 | 成员变更、后台执行、发布管理、协作读写均检查当前范围；旧个人通知与原件保留，新范围不自动开放旧内容。原发布由当前本院管理者管理；跨负责人协作需学生重新确认分享。 | 实现证据／已执行定向验证／真实外部验收；[campus.py](../../app/campus.py)；[collaboration.py](../../app/collaboration.py)；[test_campus_permissions.py](../../tests/test_campus_permissions.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py) | 学校毕业、任期与离院规则未提供，使用明确授予／修改／移除授权，不按年龄或自填年级自动推定。旧事项更正只给原收件且当前仍有权限者。 |
| LJ-007／P2 | 班委/发布协作者最小权限。可拟稿或协助范围内操作，不能直接等同辅导员；是否发布需单独授权。 | 未引入“班委即辅导员”的隐式提权；保持现有正式角色和范围校验。 | 条件扩展；[campus.py](../../app/campus.py)；[CAMPUS_PERMISSIONS.md](../CAMPUS_PERMISSIONS.md) | P2：独立拟稿／协助角色尚未建立，须明确可操作范围、发布授权和交接规则后实现。 |
| LJ-008／P2 | 如确需独立审核员、多学院或多角色，建立角色/范围/期限模型；禁止用前端角色切换模拟服务端授权。 | 未用前端身份切换模拟多学院／审核员授权；当前校园授权模型边界保持明确。 | 条件扩展；[campus.py](../../app/campus.py)；[work-context.js](../../static/work-context.js) | P2：多学院、多角色与独立审核员需真实组织范围、期限及职责规则，当前不宣称已有此模型。 |
| LJ-009／P1 | 多设备登录、共享手机退出、会话过期、迟到响应、离线缓存和Push绑定切换验证；旧账号数据不能出现在新账号页面。 | 原会话、CSRF、账号切换清理与迟到响应守卫保留；新分页和懒加载仍绑定 owner／route／请求代次，防旧账号回包落入新页。 | 实现证据／已执行定向验证／真实外部验收；[security.py](../../app/security.py)；[app.js](../../static/app.js)；[test_workflow.py](../../tests/test_workflow.py)；[paged-list.test.mjs](../../tests/paged-list.test.mjs) | 共享手机、多实际设备、浏览器缓存与后台 Push 换绑仍需实体终端矩阵。 |
| LJ-010／条件P0 | F05注销影响与历史留存：明确本人/对方记录边界，注销前预告，必要回执脱敏保留、文件授权回收；测试学生/受理人/发布人分别注销。 | `deletion-impact`展示影响；注销前保留对方最小脱敏回执，删被注销者私人说明和文件元数据，撤文件授权；已接收的正式原件继续可查，发布人匿名。 | 实现证据／已执行定向验证；[account.py](../../app/account.py)；[collaboration.py](../../app/collaboration.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 留存仅限参与事项必要动作、时间和存续方自己的说明；数据库备份依既有保留期轮换，不宣称立即物理抹除全部历史备份。 |

### B. 来源、采集与收件：LJ-011—024

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-011／P1 | 每个来源展示“手动/自动已接通/未配置/暂停/失败”、可读范围和最后成功；仅登记公众号名称不能显示自动同步成功。 | `source_sync.status`、来源卡片分别显示手动、等待、自动、部分可读、失败、暂停；显示尝试、无采集错误检查与范围。登记公众号不自动显示接通。 | 实现证据／已执行定向验证／真实外部验收；[source_sync.py](../../app/source_sync.py)；[sources.js](../../static/sources.js)；[test_source_subscriptions.py](../../tests/test_source_subscriptions.py) | 真实 QQ／公众号凭据及平台后台状态，本轮没有联调通过证据。 |
| LJ-012／P1 | 来源目录有真实覆盖证据：入口、栏目列表、正文、附件分别记录最后验证与规则版本；空列表区分真无内容和解析失效。 | `source_acquisition_runs` 保存规则／配置哈希、入口状态、列表快照、正文与附件回执；空 Feed 明确为空；异常 HTML 不算空栏目。`test_source_fetch_contracts`。 | 实现证据／已执行定向验证／真实外部验收；[source_sync.py](../../app/source_sync.py)；[notice_network.py](../../app/notice_network.py)；[test_source_fetch_contracts.py](../../tests/test_source_fetch_contracts.py) | 独立入口未实际读取仍为 registered_only；实网 DNS 失败，不能填造验证时间。 |
| LJ-013／P1 | 公共官网采集与个人订阅分层：同栏目可复用一次公开抓取，每人仍独立收件/进度；私有群/授权公众号不能跨账号共享。 | 两账号相同栏目复用一次匿名列表＋正文抓取，分别建立本人记录；越权读返回 404。`test_trusted_cross_origin_feed_public_cache_and_304_owner_separation`。 | 实现证据／已执行定向验证；[source_fetch.py](../../app/source_fetch.py)；[notice_ingest.py](../../app/notice_ingest.py)；[test_source_fetch_contracts.py](../../tests/test_source_fetch_contracts.py)；[test_source_cache_policy.py](../../tests/test_source_cache_policy.py) | 当前共享 HTTP 响应，解析及个人收件仍分别运行；未声称大型公共抓取集群或跨账号共享私有消息。 |
| LJ-014／P1 | 列表/正文条件请求、缓存与域名级限速；304正常处理，失败退避，尊重Retry-After，一个慢域名不拖住全部来源。 | ETag／Last-Modified、304、最多 30 秒缓存、64 MiB 缓存上限、持久域名租约、Retry-After；no-store／private／Set-Cookie 与不支持的 Vary 清除旧公共缓存；no-cache／max-age=0 每次复验；Age、Date、Expires 与更短有效期不被忽略。域名队列不占住另一域名空闲 worker。 | 实现证据／已执行定向验证／真实外部验收；[source_fetch.py](../../app/source_fetch.py)；[source_sync.py](../../app/source_sync.py)；[test_source_fetch_contracts.py](../../tests/test_source_fetch_contracts.py)；[test_source_cache_policy.py](../../tests/test_source_cache_policy.py) | 真实站点速率／长时吞吐仍须在部署环境验证；本轮未做高频实网压测。 |
| LJ-015／P1 | 来源改版分型、隔离试跑、版本回滚。规则候选须真实读取列表与正文后启用；不能把AI生成选择器当修复完成。 | `trial_rule`、`apply_trial`、PUT、首次预设与 rollback 共用生产 reader；失败原子保留旧版；版本冲突拒绝；回滚保持暂停；回执保留安装版本。 | 实现证据／已执行定向验证／真实外部验收；[source_sync.py](../../app/source_sync.py)；[sources.js](../../static/sources.js)；[test_source_fetch_contracts.py](../../tests/test_source_fetch_contracts.py)；[test_source_presets.py](../../tests/test_source_presets.py) | 新站改版仍需真实页面样本；规则历史与合成样本不证明未来页面结构永远可用。 |
| LJ-016／P1 | F12受信Feed跨域契约。Feed服务、允许原文域名、真实发布方分离；拦截未授权目标和危险重定向，保留原因。 | 精确 origin、真实发布方与 Feed 服务分离；默认仍同域；危险地址／跨域重定向在发请求前拦截；拒绝原因和 Feed ID 持久化。 | 实现证据／已执行定向验证；[source_sync.py](../../app/source_sync.py)；[source_fetch.py](../../app/source_fetch.py)；[test_source_fetch_contracts.py](../../tests/test_source_fetch_contracts.py) | 未擅自添加第三方 Feed 服务或声称外部提供方已授权。 |
| LJ-017／P1 | 首次导入、历史补采、断点恢复和暂停清晰。显示时间/数量边界，历史基线默认不刷屏；暂停不删除个人未完任务。 | 首轮当前列表建立静默历史基线；积压条目持久化；一次处理有上限；暂停保留通知和任务。`test_initial_website_snapshot_stays_readable_but_only_later_notices_are_announced`。 | 实现证据／已执行定向验证；[source_sync.py](../../app/source_sync.py)；[sources.js](../../static/sources.js)；[test_source_subscriptions.py](../../tests/test_source_subscriptions.py) | 不把当前栏目页等同全部历史；未实现无边界历史翻页补采。 |
| LJ-018／P1 | QQ私聊与获准群真实联调：平台权限、群主授权、逐成员订阅、@/普通消息、退群、迟到撤权、附件过期与重投。 | `test_source_subscriptions`、`test_qq_group_intake` 有群主授权、成员订阅、退群、迟到撤权、附件过期与重投场景。 | 实现证据／已执行定向验证／真实外部验收；[integrations.py](../../app/integrations.py)；[group_delivery.py](../../app/group_delivery.py)；[test_qq_group_intake.py](../../tests/test_qq_group_intake.py)；[test_source_subscriptions.py](../../tests/test_source_subscriptions.py) | 本轮未对真实 QQ 私聊／群、平台普通消息与 @ 权限做实机联调；不能标验收通过。 |
| LJ-019／P1 | 多条连发/短更正/后补附件/转发卡片做上下文关联候选；“延期了”不能无依据直接修改正式日期。 | `notice_matters.group_context_candidates` 只读取同 owner、同一当前获授权群的持久分发回执；10 分钟邻近且有更正／附件／补交信号才提候选。保留 delivery ID、message key、实际时间依据、规则窗口，未有线程或同作者证据明确为 null。复用原归组预览／确认／排除；已排除的弱邻近依据不因附件新版本复活。`test_group_context_candidates` 六例及相关群域共 41 项通过。 | 实现证据／已执行定向验证；[notice_matters.py](../../app/notice_matters.py)；[qq_group_intake.py](../../app/qq_group_intake.py)；[test_group_context_candidates.py](../../tests/test_group_context_candidates.py)；[test_notice_matters.py](../../tests/test_notice_matters.py) | 没有保留可核实回复线程时只称邻近候选，绝不编造 thread；实际 QQ 授权与真实连续消息语料仍需联调。无任何候选自动改期限、合并通知或提交材料。 |
| LJ-020／P1 | 获授权公众号真实内容/图片/附件/分页/失效联调；明确不是读取个人所有关注公众号，失去授权后正确停止。 | 授权发布账号同步已有游标、更正、分页、失效与管理员边界；`test_publisher_continuous_sync_keeps_cursor_updates_and_admin_scope` 等。 | 实现证据／已执行定向验证／真实外部验收；[publisher_sync.py](../../app/publisher_sync.py)；[integrations.py](../../app/integrations.py)；[test_source_subscriptions.py](../../tests/test_source_subscriptions.py) | 不是读取个人关注列表；本轮无真实公众号图片／附件／失权联调通过记录。 |
| LJ-021／P2 | 如试点确实使用邮箱收通知，新增入站转发或OAuth/IMAP适配；出站验证码和邮件提醒不等于已有入站邮件能力。 | 入站邮箱是清单中的条件 P2 项；本次没有真实入站邮件接口的完成证据。 | 条件扩展；[cloud_messages.py](../../app/cloud_messages.py) | 出站验证码和提醒邮件不算入站能力；需试点确认渠道与授权后接入。 |
| LJ-022／P2 | 微信群、教务SSO、企微/钉钉/飞书按实际渠道确定接口与授权；未接通先提供真实人工导入，不能做假连接按钮。 | 未连接的平台保留人工导入，来源页明确学校 SSO 仍需开放；没有伪造连接成功按钮。 | 条件扩展；[sources.js](../../static/sources.js)；[notice_intake.py](../../app/notice_intake.py) | 微信群、教务 SSO、企微／钉钉／飞书的实际范围和授权仍未建立本轮验收证据。 |
| LJ-023／P1 | 粘贴、URL、图片、PDF、Office与批量导入统一回执；部分成功可重试失败项，保留原文/原件/来源/时间，重复不重收。 | `notice_intake`／`notice_ingest` 保留正文、原件、出处、时间及重复回执；`test_unified_intake`、`test_evidence_acquisition` 覆盖重投、不同账号、版本还原与失败。 | 实现证据／已执行定向验证／真实外部验收；[notice_intake.py](../../app/notice_intake.py)；[notice_ingest.py](../../app/notice_ingest.py)；[test_unified_intake.py](../../tests/test_unified_intake.py)；[test_evidence_acquisition.py](../../tests/test_evidence_acquisition.py) | 不把受支持的文件类型等同所有真实 Office／扫描样本都可读；真实复杂批量样本仍需人工验收。 |
| LJ-024／P1 | 附件发现、下载、解析、核对、用于判断分层。扫描页、表格、低清图、缺页、超时、旧Office有样本和失败恢复，保留页码/出处与未读范围。 | `source_coverage` 区分取得原件、解析失败、待视觉核对、未读附件、保留旧快照；测试覆盖扫描、超时、第五份附件、旧 Office 失败及解压大小。 | 实现证据／已执行定向验证／真实外部验收；[source_coverage.py](../../app/source_coverage.py)；[documents.py](../../app/documents.py)；[test_evidence_acquisition.py](../../tests/test_evidence_acquisition.py) | 本轮没有新的低清真实扫描／缺页人工标准；机器接收成功不是语义核对完成。 |
### C. 通知的完整生命周期：LJ-025—044

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-025／P1 | “尚未正式公告”显式跟踪：传闻、往年规律、官方预告分别标记；允许个人跟进，不伪造正式截止/报名入口。 | `notice_phase_tracking` 区分个人线索、往年规律、官方预告；未公告只允许本人查进展安排，不创建正式窗口。独立安排幂等，复用真实日历。 | 实现证据／已执行定向验证；[notice_tracking.py](../../app/notice_tracking.py)；[notice-lifecycle.js](../../static/notice-lifecycle.js)；[test_notice_phase_tracking.py](../../tests/test_notice_phase_tracking.py) | 线索真实性仍需本人核对；系统不猜测公告日期。 |
| LJ-026／P1 | 预告→正式公告→补充→公示→结果建立关系并保留独立证据；自动关联只提候选，不自动赋予正式效力。 | 每则通知保留独立原文与版本；事项归组保留独立任务／期限；阶段跟踪绑定显式相关通知版本；相关版本变化触发 review_required。 | 实现证据／已执行定向验证；[notice_tracking.py](../../app/notice_tracking.py)；[notice_matters.py](../../app/notice_matters.py)；[test_notice_phase_tracking.py](../../tests/test_notice_phase_tracking.py)；[test_notice_matters.py](../../tests/test_notice_matters.py) | 自动相似度仅作候选，不能证明正式效力或覆盖关系。 |
| LJ-027／P1 | 已公告但尚未开放：发布时间、开放时间、本人截止、活动时间分开；可先准备，开放提醒须有明确依据。 | `TaskData.scheduled` 的 event/window 与 due_date、published_at 分离；`test_notice_timing` 检查独立事件与提醒。 | 实现证据／真实外部验收；[models.py](../../app/models.py)；[notice_lifecycle.py](../../app/notice_lifecycle.py)；[test_notice_timing.py](../../tests/test_notice_timing.py) | 不凭发布时间生成开放提醒；真实开放平台／个人资格仍由使用者核实。 |
| LJ-028／P1 | “已发但未采到”可诊断：显示最后尝试/成功、来源失败、覆盖范围和人工补收入口，不把没采到解释为没有通知。 | 来源页有尝试、成功、错误、范围、积压与人工转入；`recent_failures` 只返回本人已启用来源；同故障稳定键含最近成功轮次。 | 实现证据／已执行定向验证；[source_sync.py](../../app/source_sync.py)；[sources.js](../../static/sources.js)；[test_source_fetch_contracts.py](../../tests/test_source_fetch_contracts.py) | 应用 DNS 失败就是未完成采集，不能解释为学校没有通知。 |
| LJ-029／P1 | 校级原发、学院细化、群转发、截图与口头转述的来源链清楚；区分发布单位、转载单位、文中提及单位。 | 来源原文、parent_url、relationship、Feed 服务／真实发布方、列表／正文日期分别保留；候选关系有未核实标记。 | 实现证据／已执行定向验证／真实外部验收；[notice_network.py](../../app/notice_network.py)；[notice_ingest.py](../../app/notice_ingest.py)；[test_source_fetch_contracts.py](../../tests/test_source_fetch_contracts.py)；[test_evidence_acquisition.py](../../tests/test_evidence_acquisition.py) | 发布／转载／提及单位的语言语义仍需人工核对，不凭名称关键词自动认证组织身份。 |
| LJ-030／P1 | 校级截止与学院内部截止并存，冲突并排核对；不能用收到时间或AI置信度自动决定哪个更有效。 | `test_group_preserves_independent_requirements_deadlines_and_personal_plans` 保留校级与学院通知各自任务、期限和个人计划。 | 实现证据／已执行定向验证／真实外部验收；[notice_matters.py](../../app/notice_matters.py)；[workflow.py](../../app/workflow.py)；[test_notice_matters.py](../../tests/test_notice_matters.py) | 冲突效力由本人依据核实；收到时间和模型置信度不决定优先级。 |
| LJ-031／条件P0 | F03同URL跨年度/批次新建事项。覆盖同批更正、相似模板新年、第二轮、补录、迟到旧版及旧材料历史。 | `test_intake_round_isolation` 四场景：复用 URL 跨年、同批更正、迟到旧版、同文第二轮／补录、同业务年跨日历年、明确校园发布修订。 | 实现证据／已执行定向验证；[notice_ingest.py](../../app/notice_ingest.py)；[notice_network.py](../../app/notice_network.py)；[test_intake_round_isolation.py](../../tests/test_intake_round_isolation.py) | 保守结构规则不能解决没有任何年份／批次线索的语义歧义；可用既有人工新副本、归组与拆分。 |
| LJ-032／P1 | 同文多入口去重保留所有出处；相似标题但不同对象/轮次不误合并；人工拆分/合并保留可追踪关系。 | 相同正文跨入口复用但保留收件出处；不同年份／批次不合并；人工归组／拆分保留各自通知和办理记录。`test_unified_intake`、`test_notice_matters`。 | 实现证据／已执行定向验证；[notice_ingest.py](../../app/notice_ingest.py)；[notice_matters.py](../../app/notice_matters.py)；[test_unified_intake.py](../../tests/test_unified_intake.py)；[test_notice_matters.py](../../tests/test_notice_matters.py) | 字节相同文件的新名称是元数据，校园共享原件名称历史由校园专项核查；未把相似标题直接判同一事项。 |
| LJ-033／P1 | 必办、自愿、待资格核实、仅知悉、不适用、考虑中分别呈现；一条通知可包含多种动作，不强制全部变待办。 | 现有任务 action_kind／participation、通知知悉／不适用处理和逐动作条件分离；阶段跟踪没有替代这些状态。 | 实现证据／真实外部验收；[models.py](../../app/models.py)；[proactive_policy.py](../../app/proactive_policy.py)；[test_proactive_policy.py](../../tests/test_proactive_policy.py)；[test_action_workflow.py](../../tests/test_action_workflow.py) | 多动作真实校园通知仍需样本验证；未知资格不等于不适用。 |
| LJ-034／P1 | “为什么与我有关”可查看已核实条件、自填资料与未知条件；纠错影响后续判断但不改写原公告。 | `proactive_policy.assess` 只使用当前通知／画像版本且已核对的适用结论；兴趣关键词只影响偏好，不认证资格；不充分结论保留待核实。 | 实现证据／已执行定向验证／真实外部验收；[proactive_policy.py](../../app/proactive_policy.py)；[notice_automation.py](../../app/notice_automation.py)；[test_proactive_policy.py](../../tests/test_proactive_policy.py)；[test_proactive_tracking.py](../../tests/test_proactive_tracking.py) | 本轮未取得真实画像与独立人工适用标准，不能报告真实判断准确率。 |
| LJ-035／P1 | 时间抽取区分日期/时刻/范围/时区/待定；无具体时刻不自行补23:59，无结束时间不编活动时长。 | 原文日期、时刻、范围、明确时区分别校验；异议窗口复用 `deadline_evidence`。未知时刻不保存 23:59，未知活动结束不编时长。 | 实现证据／已执行定向验证／真实外部验收；[deadline_evidence.py](../../app/deadline_evidence.py)；[models.py](../../app/models.py)；[test_notice_phase_tracking.py](../../tests/test_notice_phase_tracking.py)；[test_notice_timing.py](../../tests/test_notice_timing.py) | 相对日期需要原文发布日期和时区；省略年份不能仅据今年猜补。 |
| LJ-036／P1 | F02活动/窗口正式改期：开始、结束、跨日、提前/延期、取消时刻；旧日历、个人计划、依赖事项都给影响说明。 | 正式 event／window 改期绑定当前原文证据与通知版本；支持开始、结束、跨日及撤销结束时刻，保留本人计划并给依赖影响；不以个人安排冒充正式更正。 | 实现证据；[workflow.py](../../app/workflow.py)；[models.py](../../app/models.py)；[test_sprint_official_time.py](../../tests/test_sprint_official_time.py)；[test_change_review.py](../../tests/test_change_review.py) | 对应测试已纳入冻结后端全量记录；结论限实际测试断言，不将源码存在视作额外真实环境验收。 |
| LJ-037／P1 | 地点、提交入口、联系人、资格、模板、费用口径变化逐字段比较；突出已准备/已提交材料受哪些影响。 | 来源更新先成为待核对变化，保留旧证据、已提交／已准备历史；`test_action_workflow` 与 `test_change_review` 覆盖要求变化和依赖。 | 实现证据／真实外部验收；[workflow.py](../../app/workflow.py)；[action_review.py](../../app/action_review.py)；[test_action_workflow.py](../../tests/test_action_workflow.py)；[test_change_review.py](../../tests/test_change_review.py) | 复杂费用／模板语义仍需真实样本，未声称全部自然语言变化可自动解释。 |
| LJ-038／P1 | 原文404、下架、栏目移除、平台采集失败和正式撤回分别处理；来源不可访问不得自动取消本人任务。 | HTTP／连接／附件失败记为来源问题；保留已读旧快照并标本轮未复查；不自动取消任务。`test_failed_related_recheck_preserves_last_snapshot_and_original_retrieval_time`。 | 实现证据／已执行定向验证；[notice_network.py](../../app/notice_network.py)；[source_sync.py](../../app/source_sync.py)；[test_proactive_tracking.py](../../tests/test_proactive_tracking.py)；[test_source_subscriptions.py](../../tests/test_source_subscriptions.py) | 原文撤回需要正式证据，404、维护、权限失败与正式取消不同。 |
| LJ-039／P1 | 取消只影响明确对象/场次；恢复必须有新依据，重新核对日期和要求；保留已做历史，不复活所有旧提醒。 | 既有变更目标、版本和证据约束；取消／恢复不抹除历史，已完成保护与设备日历提示独立。`test_cancellation_restoration_and_completed_protection`。 | 实现证据／真实外部验收；[workflow.py](../../app/workflow.py)；[action_review.py](../../app/action_review.py)；[test_action_workflow.py](../../tests/test_action_workflow.py)；[test_change_review.py](../../tests/test_change_review.py) | 不把恢复关注当作资格恢复；真实场次歧义需核实。 |
| LJ-040／P1 | 多批次、多场次、本硕博、年级差异与联合团队拆分子流程；大事项聚合不吞掉各自期限和资格。 | 事项聚合保留成员通知，各自期限和任务不合并；新轮次、跨年度隔离。 | 实现证据／已执行定向验证／真实外部验收；[notice_matters.py](../../app/notice_matters.py)；[notice_ingest.py](../../app/notice_ingest.py)；[test_notice_matters.py](../../tests/test_notice_matters.py)；[test_intake_round_isolation.py](../../tests/test_intake_round_isolation.py) | 本硕博／联合团队的具体子流程仍依真实材料拆分，不按名单或标题自行推断。 |
| LJ-041／P1 | 公示/异议模板：公示结束不等最终结果，异议意愿、材料、窗口和回执独立；同名名单不能模糊命中即下结论。 | 公示结束标记与结果无自动转换；异议意愿、明确窗口、现有任务材料和回执独立；本人结果需要身份核实说明；有越权／伪造引句／过期版本测试。 | 实现证据／已执行定向验证／真实外部验收；[notice_tracking.py](../../app/notice_tracking.py)；[notice-lifecycle.js](../../static/notice-lifecycle.js)；[test_notice_phase_tracking.py](../../tests/test_notice_phase_tracking.py) | 同名检索不能直接下结论；本轮没有真实异议业务办理／官方受理回执。 |
| LJ-042／P1 | 结果后的入选/落选/候补/补录、名额确认、领取、签约、报到作为后续动作；已过报名期不压掉结果提醒。 | 支持入围、入选、未入选、候补、补录；关联确认名额／领取／签约／报到等真实任务；主通知模块 `phase_updates` 用当前阶段版本生成独立事件，不以旧报名期限抑制。 | 实现证据／已执行定向验证／真实外部验收；[notice_tracking.py](../../app/notice_tracking.py)；[notification_events.py](../../app/notification_events.py)；[test_notice_phase_tracking.py](../../tests/test_notice_phase_tracking.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py) | 外发仍按主通知模块的本人偏好与渠道授权，未做真实设备到达验收；本人记录不等于学校最终确认。 |
| LJ-043／P1 | 归档/不参加/已完成后仍可接收确实影响本人的新更正；恢复关注不等于重新开放或重新符合资格。 | 更正保留已完成任务与材料，不因旧阶段完成而丢弃来源更新；`test_completed_action_still_receives_correction_reminder`、变更复核链。 | 实现证据／已执行定向验证；[notice_ingest.py](../../app/notice_ingest.py)；[proactive_policy.py](../../app/proactive_policy.py)；[test_proactive_tracking.py](../../tests/test_proactive_tracking.py)；[test_push_delivery.py](../../tests/test_push_delivery.py) | 新更正仍需本人核实效力与资格；不会自动复活所有旧提醒。 |
| LJ-044／P1 | 原文状态、平台处理状态、个人办理状态、触达状态分开命名和显示；“已读/已核对/已提交/已受理/已办结”不得混用。 | 原文阶段、采集覆盖、平台处理、个人办理、提交／受理和触达分开；生命周期面板关联现有回执而不覆盖任务进度。 | 实现证据／已执行定向验证／真实外部验收；[notice_tracking.py](../../app/notice_tracking.py)；[source_coverage.py](../../app/source_coverage.py)；[test_notice_phase_tracking.py](../../tests/test_notice_phase_tracking.py)；[test_action_workflow.py](../../tests/test_action_workflow.py) | Provider accepted 不代表设备展示或本人已读，官方办理结果需独立依据。 |

### D. 办理、材料与个人日程：LJ-045—056

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-045／P1 | 首页/待办首先回答“下一步做什么、何时、为什么卡住”；完整流程保留在详情，避免多个警告标签代替行动。 | 新增统一任务摘要，每行集中主状态、关键时间与下一步；依赖、补件、待结果等完整原因保留在办理详情。 | 实现证据／已执行定向验证；[task-summary.js](../../static/task-summary.js)；[app.js](../../static/app.js)；[task-summary.test.mjs](../../tests/task-summary.test.mjs)；[test_action_workflow.py](../../tests/test_action_workflow.py) |  |
| LJ-046／P1 | 前置未完成时明确哪些准备仍可做；受阻、等待他人、等待结果、尚未开放分开，并有合理跟进时间。 | 办理工作流保留依赖关系与可准备步骤；受阻、等他人、等结果、尚未开放分别表达；本人跟进时刻与官方期限独立。 | 实现证据；[workflow.py](../../app/workflow.py)；[action_review.py](../../app/action_review.py)；[test_action_workflow.py](../../tests/test_action_workflow.py)；[test_change_review.py](../../tests/test_change_review.py) |  |
| LJ-047／P1 | 一通知多任务/可选步骤/先线上后纸质/本人自定义步骤维持一致；一个子任务完成不能自动代表全部办理完成。 | 沿用一通知多任务、动作种类、前置关系和本人自定义流程；各任务独立状态，阶段归组与后续跟踪不自动完成全部动作。 | 实现证据／已执行定向验证；[workflow.py](../../app/workflow.py)；[models.py](../../app/models.py)；[test_action_workflow.py](../../tests/test_action_workflow.py)；[test_workflow.py](../../tests/test_workflow.py) |  |
| LJ-048／P1 | 模板文件、本人的填写版本、已提交包分离；提交冻结文件版本/哈希/时间/去向，新补件不篡改旧回执。 | 原通知模板、本人材料版本与提交快照分表存储；提交固定版本、哈希、去向和时间，补件追加不会改写旧提交包。 | 实现证据；[task_materials.py](../../app/task_materials.py)；[workflow.py](../../app/workflow.py)；[test_task_materials.py](../../tests/test_task_materials.py)；[test_action_workflow.py](../../tests/test_action_workflow.py) |  |
| LJ-049／P1 | 误选材料、上传中断、同名新版本、删除/撤回、容量满有恢复；被他人已接收的固定版本按授权与留存规则处理。 | 已有材料版本、幂等上传、旧版本冲突、容量门禁和授权下载；校园共享原件补齐实际字节计量及原件引用，最小留存回收对方文件授权。 | 实现证据／已执行定向验证／真实外部验收；[task_materials.py](../../app/task_materials.py)；[campus_assets.py](../../app/campus_assets.py)；[test_task_materials.py](../../tests/test_task_materials.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py) | 真实大文件和移动网络中断恢复仍须现场样本验证。 |
| LJ-050／P1 | 真实提交与本站记录区别清楚。外部表单只打开链接不能显示已提交；本人确认需有明确去向及可选凭据。 | 外部链接打开与本人记录提交分开；提交须本人明确去向和时间，可附凭据；系统没有校外表单回执时不显示学校已受理。 | 实现证据；[task_materials.py](../../app/task_materials.py)；[workflow.py](../../app/workflow.py)；[test_task_materials.py](../../tests/test_task_materials.py)；[test_action_workflow.py](../../tests/test_action_workflow.py) |  |
| LJ-051／P1 | 提交→受理→补件→再提交→驳回/结果/办结保留每段证据；无外部回执时标本人记录，不伪装学校确认。 | 办理记录保留提交、受理、补件、补交、驳回／结果和办结各阶段；协作受理是范围内真实站内动作，外部状态按本人记录标注。 | 实现证据／已执行定向验证；[workflow.py](../../app/workflow.py)；[collaboration.py](../../app/collaboration.py)；[test_action_workflow.py](../../tests/test_action_workflow.py)；[test_pilot_workspace.py](../../tests/test_pilot_workspace.py) |  |
| LJ-052／P1 | 重复提交、双击、断线重试、旧版本409均保留输入、只生成一次业务动作；冲突有具体恢复入口。 | 事务、版本和请求回执约束双击／断线重试；旧版本返回 409 并保留表单，正式改期拒绝无依据或外部 owner 的变更。 | 实现证据；[workflow.py](../../app/workflow.py)；[task_materials.py](../../app/task_materials.py)；[test_workflow.py](../../tests/test_workflow.py)；[test_sprint_official_time.py](../../tests/test_sprint_official_time.py) | 所有真实浏览器输入保留与焦点恢复仍由冻结浏览器套件验证。 |
| LJ-053／P1 | 不参加/撤销申请/取消本人计划与学校取消分离；后续可恢复本人关注，不删除原文和历史。 | 本人不参加、申请撤回、取消个人安排与校方正式取消分别保留；恢复关注不更改原文资格或抹去旧办理回执。 | 实现证据；[workflow.py](../../app/workflow.py)；[notice_intake.py](../../app/notice_intake.py)；[test_action_workflow.py](../../tests/test_action_workflow.py)；[test_schedule.py](../../tests/test_schedule.py) |  |
| LJ-054／P1 | 课程、个人安排、官方活动、报名截止在日历有明确类型；个人拖动安排不能悄悄改官方截止。 | 课程、安排、正式 event／window 与截止分别建模；日历读取各自类型，个人安排编辑不覆盖正式期限；课程外发需每项显式选择。 | 实现证据；[schedule.py](../../app/schedule.py)；[workflow.py](../../app/workflow.py)；[test_schedule.py](../../tests/test_schedule.py)；[test_sprint_official_time.py](../../tests/test_sprint_official_time.py) |  |
| LJ-055／P1 | ICS导出、本人确认导入、真机提醒验证分层；按设备保存核对记录，验证稳定UID、更正/取消和重复导入。 | 既有 ICS 稳定 UID、版本变更／取消及往返解析合同保留；设备导入核对是本人记录且绑定版本，不能等同设备已提醒。 | 实现证据／真实外部验收；[workflow.py](../../app/workflow.py)；[schedule.py](../../app/schedule.py)；[test_workflow.py](../../tests/test_workflow.py)；[test_action_workflow.py](../../tests/test_action_workflow.py) | 实际 Android／iOS／桌面日历导入、重复导入及更正取消提醒须实体设备记录。 |
| LJ-056／P2 | 订阅式日历/CalDAV/外部日历API作为独立功能评估；可撤销令牌、版本变更、权限和真实终端同步均需验收。 | 保持当前显式 ICS 导出与本人核对；没有把文件下载称为订阅式日历。 | 条件扩展；[schedule.py](../../app/schedule.py)；[calendar.js](../../static/calendar.js) | P2：CalDAV／订阅令牌／外部日历 API 尚未实现，需决定终端、授权、撤销及同步规则。 |

### E. 发布、审核与协作：LJ-057—068

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-057／P1 | 发布草稿持久化、附件状态、自动保存提示和离开恢复；草稿不分发、不提醒、不算已发布。 | `campus_drafts.py`保存未完整正文／范围和原附件；每人最多50份；版本冲突409；刷新、重启、另一端可取；发布成功删本草稿。前端自动保存状态和冲突保留输入。 | 实现证据／已执行定向验证；[campus_drafts.py](../../app/campus_drafts.py)；[campus.js](../../static/campus.js)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 草稿不分发、不提醒、不计为已发布；网络失败而未保存的输入须继续重试。 |
| LJ-058／P1 | F01服务端强制受众复核；人数相同但成员变化也要失效；发布预览分学生/工作人员和具体范围。 | 随机复核凭据绑定发布人完整授权、受众范围、具体成员／角色／授权版本；省略、过期、同人数换人、重启旧签名均拒绝；已提交请求按幂等回执恢复。 | 实现证据／已执行定向验证；[campus.py](../../app/campus.py)；[campus.js](../../static/campus.js)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 核对不是校方审批。旧请求的幂等重放仍先验证当前发布权限，不能借重放绕过撤权。 |
| LJ-059／P1 | 零学生、空范围、预计附件总量、超限和身份将失效在发布前提示；不能只给“共3人”掩盖无人属于目标学生群。 | 复核分学生和工作人员；零学生单列警告；返回1000人／3附件／8MiB容量边界，附件投影带实际size／SHA。单文件5MiB、文本总量10000字，原件和草稿存储预算强制执行。 | 实现证据／已执行定向验证／真实外部验收；[campus.py](../../app/campus.py)；[campus_assets.py](../../app/campus_assets.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 没有机构任职到期数据，不显示虚构的“身份即将过期”；执行时仍查当前授权。容量上限不是吞吐量保证。 |
| LJ-060／P1 | F06附件共享引用与分批持久分发；任务回执快速返回，逐人失败可恢复，角色/范围变化在执行时复核。 | `campus_assets.py`不可变原件＋归属通知的授权引用；短事务逐人处理，默认每批24人；后台续传、逐人失败、撤权复核；逻辑容量保持。 | 实现证据／已执行定向验证／真实外部验收；[campus.py](../../app/campus.py)；[campus_assets.py](../../app/campus_assets.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 测试证明此样本与故障边界，不据此宣称全部硬件上的1000人性能。 |
| LJ-061／P1 | 已发布正文/附件更正有版本和影响摘要；回滚旧内容也产生新版本，不重写审计历史。 | 正式版本史和授权原件下载、正文／标题／附件摘要；回滚新建版本，记录原因与目标版本。有效期沿用所选历史版本。同内容附件改名更新本人名称，保存旧新名审计，不换source_id／原件。 | 实现证据／已执行定向验证；[campus.py](../../app/campus.py)；[campus_assets.py](../../app/campus_assets.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 回滚不重写过去审计；撤回版本须走正式恢复。 |
| LJ-062／P1 | 发布方撤回后正式恢复链路，显示撤回→恢复及新版本；本人任务restoration不能代替发布方恢复。 | 独立`restore`接口，要求当前撤回版本及实际说明；保留撤回→恢复链，生成新版本、重新投递原合法受众。个人任务状态不被强制恢复。 | 实现证据／已执行定向验证／真实外部验收；[campus.py](../../app/campus.py)；[campus_policy.py](../../app/campus_policy.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 正式恢复由当前有权发布者／管理者确认原文依据；系统不杜撰恢复公告。 |
| LJ-063／P1 | 新入班/晚加入补发当前有效版本；已收不重复、撤回不补发、历史过期明确说明；补发不自动重启旧任务。 | 补发强制当前版本＋新受众复核。当前授权成员才可新增，已收不重复、撤回不补发。显式有效期／历史参考由发布人填写；过期／参考须确认参考用途并抑制外发。 | 实现证据／已执行定向验证；[campus_policy.py](../../app/campus_policy.py)；[campus.py](../../app/campus.py)；[test_campus_policies.py](../../tests/test_campus_policies.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py) | 不从正文猜有效期；未填显示“未设置有效期”。历史站内记录保留，补发不创建或重启任务。 |
| LJ-064／P2 | 如学院需要送审：拟稿、送审、驳回、撤回、修改重审、审批失效、并发审核；修改内容后旧审批不能继续生效。 | 保持原清单“如学院需要”的P2条件，没有把受众核对冒充独立审批。 | 条件扩展；[campus.py](../../app/campus.py) | 需明确拟稿人、审核员、审批失效与权限条件，尚未建立独立送审流。 |
| LJ-065／P2 | 定时发布：编辑/取消/失权/错过时刻/重启补偿有规则；执行时重核受众、附件与审批，不误发重复公告。 | 保持P2独立功能边界；本轮持久队列处理的是已经明确发布的收件任务，草稿不因时间而自动发布。 | 条件扩展；[campus_drafts.py](../../app/campus_drafts.py)；[campus.py](../../app/campus.py) | 未建立定时发布及送审执行链，不能把后台分发队列称为定时公告。 |
| LJ-066／P1 | 发布统计分站内分发、渠道接受、用户打开、显式回执；不将私人待办完成率默认暴露为管理看板。 | 站内分发独立显示。`campus_policy.delivery_evidence`仅用现存30天Push／邮件收件引用台账计算状态、次数、不同账号数，显示供应商接受≠展示。本人打开、显式回执无证据时为null／unknown。 | 实现证据／已执行定向验证／真实外部验收；[campus_policy.py](../../app/campus_policy.py)；[campus-delivery-evidence.js](../../static/campus-delivery-evidence.js)；[test_campus_policies.py](../../tests/test_campus_policies.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py) | 无真实平台回执时不宣称真实发送成功；没有发布级打开／确认采集，就如实显示未知，不从私人办理数据推断。 |
| LJ-067／P1 | 协作接收、拒收/不再负责、补件、补交、办结、撤回和超时跟进完善；跨负责人转交需重新确认分享范围。 | 新增拒收／不再负责、重新确认负责人和材料的转交、每人独立跟进时刻。改期／取消有版本；跟进不更改校方截止、原task或对方设置；关闭／撤权／注销停止。 | 实现证据／已执行定向验证；[collaboration.py](../../app/collaboration.py)；[collaboration_followups.py](../../app/collaboration_followups.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 跟进到期后按本人提醒偏好计算，未到期计划在协作详情可见；不冒充校方超时结论。 |
| LJ-068／P1 | 交接与审计按职责范围分页筛选；只共享明确选定的通知/材料版本，系统管理员和无关成员仍不可读。 | 发布记录按权限SQL过滤、分页搜索；管理审计使用before_id游标及action筛选；协作收件箱在SQL分页合并活动和留存回执；材料分享固定明确版本。 | 实现证据／已执行定向验证；[campus.py](../../app/campus.py)；[collaboration.py](../../app/collaboration.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py)；[test_campus_policies.py](../../tests/test_campus_policies.py) | 系统管理员不能仅凭系统身份读取协作；辅导员查看本人合法发布版本史，不扩大为整个组织审计读取权。 |

### F. 提醒、投递与用户控制：LJ-069—084

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-069／P1 | 建立统一提醒事件与通道矩阵：新公告、开放、期限、改期、取消、补件、结果、跟进、来源故障分别定义。 | 统一类别与具体事件矩阵覆盖新公告、开放、期限、更正、取消、补件、公示结果、跟进与来源失败；计划只反映当前授权和版本。 | 实现证据；[notification_events.py](../../app/notification_events.py)；[notification_routing.py](../../app/notification_routing.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py) |  |
| LJ-070／P1 | F04按认可范围补个人安排/课程/协作离线提醒；先明确每类支持什么渠道，课表导入不默认强开提醒。 | 个人安排／课程新增逐项 reminder_minutes 显式授权，协作进度和个人跟进共用当前队列；课程导入与 JSON 恢复不默认恢复外发同意。 | 实现证据／已执行定向验证／真实外部验收；[notification_events.py](../../app/notification_events.py)；[schedule.py](../../app/schedule.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py) | 真实渠道／设备端到端与实际故障恢复须附各平台证据，当前合成合同不能替代。 |
| LJ-071／P1 | 首次开启渠道明确授权、邮箱验证、设备绑定、所含内容和作用范围；通道尚不可用不显示绿色已启用。 | 设备权限、渠道配置、验证邮箱与本人同意分别校验；读取通道状态和运行就绪，缺配置不返回可发送成功。 | 实现证据／真实外部验收；[push_delivery.py](../../app/push_delivery.py)；[mail_delivery.py](../../app/mail_delivery.py)；[test_push_delivery.py](../../tests/test_push_delivery.py)；[test_mail_delivery.py](../../tests/test_mail_delivery.py) | 真实渠道／设备端到端与实际故障恢复须附各平台证据，当前合成合同不能替代。 |
| LJ-072／P1 | 按类别/事项/来源设置立即、摘要、仅站内、不提醒；本人任务提醒与来源新收件偏好可分别管理。 | 类别、本人通知及实际来源各可配置立即／摘要／仅站内／关闭；来源路由 ID 按 owner 验证，多来源使用保守限制并允许本人事项显式覆盖。 | 实现证据；[notification_routing.py](../../app/notification_routing.py)；[notification_events.py](../../app/notification_events.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py)；[test_sprint_observability.py](../../tests/test_sprint_observability.py) |  |
| LJ-073／P1 | 免打扰、临近截止、提前/紧急更正冲突可解释；是否突破静默须用户明确选择，不能由AI暗中决定。 | 免打扰、摘要和有效窗口统一计算；延后至失效窗口外即抑制，紧急更正突破静默须本人显式 allow_urgent_during_quiet。 | 实现证据；[notification_events.py](../../app/notification_events.py)；[proactive_policy.py](../../app/proactive_policy.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py) |  |
| LJ-074／P1 | 稍后提醒与自定义时刻可撤销，若晚于截止清晰提醒；改期、取消、办结会重新核对旧计划。 | 保留个人稍后／自定时间与正式期限分离；正式提前触发旧计划核对，取消、完成与删除撤销发送；协作跟进可改期或取消。 | 实现证据／已执行定向验证；[workflow.py](../../app/workflow.py)；[action_review.py](../../app/action_review.py)；[test_change_review.py](../../tests/test_change_review.py)；[test_push_delivery.py](../../tests/test_push_delivery.py) |  |
| LJ-075／P1 | 同一事项多来源、多更正、多渠道聚合但保留关键差异；摘要窗口内又取消的消息不能继续当有效行动发送。 | 各通道按真实 event_refs／receipt_refs 聚合仍有效摘要；已接受组成项不因偏好变化重发，发送前重算取消和失效项。 | 实现证据；[notification_events.py](../../app/notification_events.py)；[proactive_policy.py](../../app/proactive_policy.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py)；[test_push_delivery.py](../../tests/test_push_delivery.py) |  |
| LJ-076／P1 | 首次历史导入、设备新绑定、恢复备份、停机积压不重放海量历史提醒；仅处理仍有效且符合偏好的事件。 | 来源历史基线、新设备基线、邮件同意时点及恢复环境隔离；导入不恢复外发同意，停机后仅考虑仍有效事件。 | 实现证据／已执行定向验证；[push_delivery.py](../../app/push_delivery.py)；[mail_delivery.py](../../app/mail_delivery.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py)；[test_push_delivery.py](../../tests/test_push_delivery.py) |  |
| LJ-077／P1 | “为什么没提醒/为什么又提醒”详情：不适用、静默、摘要、未授权、设备失效、已取消、失败、状态未知可见。 | 计划 API 展示类别、原时刻、偏好延迟、抑制原因和可用通道；站内、队列与最近投递台账分开，失败和未知状态不隐去。 | 实现证据；[notification_events.py](../../app/notification_events.py)；[push_delivery.py](../../app/push_delivery.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py)；[test_push_delivery.py](../../tests/test_push_delivery.py) |  |
| LJ-078／P1 | 计划、排队、发送中、供应商接受、未知、设备展示、本人打开分层；仅记录可证明状态，不写虚假已读。 | 保留计划、排队、发送中、provider accepted、uncertain 等可证实层级；无设备展示／本人打开采集证据时不补造状态。 | 实现证据／已执行定向验证／真实外部验收；[push_delivery.py](../../app/push_delivery.py)；[mail_delivery.py](../../app/mail_delivery.py)；[test_push_delivery.py](../../tests/test_push_delivery.py)；[test_mail_delivery.py](../../tests/test_mail_delivery.py) | 真实渠道／设备端到端与实际故障恢复须附各平台证据，当前合成合同不能替代。 |
| LJ-079／P1 | 重试、租约过期、429、限流、服务崩溃、邮件uncertain覆盖；未知已发结果不盲目自动重发。 | 持久租约、有限重试、429 与已失效设备清理；未知邮件提交结果进入 uncertain 而不盲目重发；旧 worker 不覆盖新租约或用户解绑。 | 实现证据／真实外部验收；[push_delivery.py](../../app/push_delivery.py)；[mail_delivery.py](../../app/mail_delivery.py)；[test_push_delivery.py](../../tests/test_push_delivery.py)；[test_mail_delivery.py](../../tests/test_mail_delivery.py) | 真实渠道／设备端到端与实际故障恢复须附各平台证据，当前合成合同不能替代。 |
| LJ-080／P1 | 多设备主设备/全部设备策略、退出解绑、换账号、过期订阅、撤销权限与锁屏隐私验证。 | 采用所有本人已启用设备分别投递与独立去重；Push 状态 API 明确返回 all_enabled_devices 及中文边界，逐设备关闭不替其他设备撤权。未擅自改默认策略或伪装已有主设备选项。 | 实现证据／真实外部验收；[push_delivery.py](../../app/push_delivery.py)；[proactive-notifications.js](../../static/proactive-notifications.js)；[test_push_delivery.py](../../tests/test_push_delivery.py) | 真实渠道／设备端到端与实际故障恢复须附各平台证据，当前合成合同不能替代。 |
| LJ-081／P1 | Android、iOS、桌面在前台/后台/锁屏/浏览器关闭/断网恢复真机矩阵；明确系统条件和不能保证的场景。 | 工程合同区分前台站内、Push 与邮件；实体系统条件和后台/锁屏限制保留，不能由模拟 push 或供应商接受推断展示。 | 实现证据／真实外部验收；[push_delivery.py](../../app/push_delivery.py)；[mail_delivery.py](../../app/mail_delivery.py)；[test_push_delivery.py](../../tests/test_push_delivery.py)；[test_mail_delivery.py](../../tests/test_mail_delivery.py) | 真实渠道／设备端到端与实际故障恢复须附各平台证据，当前合成合同不能替代。；Android、iOS、桌面前台／后台／锁屏／浏览器关闭／断网恢复真机矩阵本轮未完成。 |
| LJ-082／P1 | 已完成或已读旧版但新更正影响本人时仍可提醒；不相关判断在资格/对象改变后允许重核，防永久压制。 | 旧完成或已读不会吞掉新版重要更正；适用判断绑定当前通知和个人资料版本，资格改变可重新核对，旧审核不永久抑制。 | 实现证据／已执行定向验证；[push_delivery.py](../../app/push_delivery.py)；[proactive_policy.py](../../app/proactive_policy.py)；[test_push_delivery.py](../../tests/test_push_delivery.py)；[test_proactive_tracking.py](../../tests/test_proactive_tracking.py) |  |
| LJ-083／P1 | 管理者公告不能强开学生外发渠道；敏感事项默认最小锁屏摘要，完整内容回到鉴权页面。 | 校园发布只决定合法站内分发；学生外发须本人偏好和渠道同意，协作／结果／来源故障默认锁屏文案不含私人材料细节。 | 实现证据／已执行定向验证／真实外部验收；[campus.py](../../app/campus.py)；[notification_events.py](../../app/notification_events.py)；[test_campus_permissions.py](../../tests/test_campus_permissions.py)；[test_sprint_notifications.py](../../tests/test_sprint_notifications.py) | 真实渠道／设备端到端与实际故障恢复须附各平台证据，当前合成合同不能替代。 |
| LJ-084／P1 | 运维告警独立于学生提醒：来源持续失败、最老队列年龄、凭证过期、磁盘/备份、预算；去重、确认和恢复通知闭环。 | 新增独立管理员运维事件及站内消息，检测最老逾期队列、连续来源失败、磁盘、备份时效、登记凭证期限与额度计数；持久去重、接手确认、恢复和复发分开，unknown 不自动关闭事故；恢复实例不沿用原环境。 | 实现证据／真实外部验收；[operations_monitor.py](../../app/operations_monitor.py)；[observability.py](../../app/observability.py)；[test_operations_monitor.py](../../tests/test_operations_monitor.py)；[test_sprint_observability.py](../../tests/test_sprint_observability.py) | 真实渠道／设备端到端与实际故障恢复须附各平台证据，当前合成合同不能替代。 |

### G. 前端和移动端：LJ-085—110

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-085／P1 | F07样式分层和组件所有权整理，确认最终断点/字号/间距；学院页与事项页纳入统一层序，删除被覆盖旧策略。 | 学院、事项、材料 CSS 进入统一 legacy/system 层序；删除独立无层 link 和运行时材料 link，修正 bundle 相对路径。已有各 feature CSS 保持必要规则，未凭静态猜测整片删除。 | 实现证据；[styles.css](../../static/styles.css)；[index.html](../../static/index.html) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-086／P1 | 保持珞珈绿、白底和当前导航习惯；制定手机/桌面密度token，避免每个页面继续各写一套尺寸补丁。 | 保留珞珈绿/白底与原导航。统一 control-target=44px 和 page/row 密度 token，明确 850px 断点；没有 scale 全页缩小。 | 实现证据；[tokens.css](../../static/system/tokens.css)；[responsive-density.css](../../static/system/responsive-density.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-087／P1 | F08点击面积与视觉大小分离，重点更多菜单/勾选/拖动/聊天按钮；不用统一scale缩小，触达面积不相互覆盖。 | 任务勾选、更多、拖动、聊天入口用独立 44px 格；删除桌面负 margin 并保留视觉图标大小。 | 实现证据；[workspace-clarity.css](../../static/system/workspace-clarity.css)；[chat-conversation.css](../../static/system/chat-conversation.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-088／P1 | 手机通知页压缩顶部层数：标题与收件动作同行，搜索主行，次要筛选收起并显示生效摘要；首条内容更早出现。 | 主行搜索和收通知；来源/日期/关系/展示方式在明确 disclosure 内，筛选摘要保持可见，列表范围显示已加载/总匹配。 | 实现证据；[library.js](../../static/library.js)；[workspace-clarity.css](../../static/system/workspace-clarity.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-089／P1 | 首页/待办每行一个主状态、一个关键日期、一句下一步；多警告收为可展开摘要，重要变更仍明显。 | 一项主状态、一项关键时间和下一步；重要变更优先，多警告放更多菜单，未核实时间不冒充有效期限。 | 实现证据；[task-summary.js](../../static/task-summary.js)；[app.js](../../static/app.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-090／P1 | 手机待办分组与列表策略统一；长标题自适应，拖动有菜单/键盘替代，点击正文与完成/更多区域不打架。 | 保留分组、长标题换行；拖动入口明确提供点按/Enter 位置选择；当前加载范围写明，避免把 50 项当全部。 | 实现证据；[task-views.js](../../static/task-views.js)；[workspace-clarity.css](../../static/system/workspace-clarity.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-091／P1 | F09完成动效只响应服务端成功；失败回滚、打开办理、阻塞/补件、撤销/取消均不播放完成庆祝。 | 移除全局点击捕获庆祝；只有同账号/同路由的服务端 done 回执后庆祝。失败回滚、打开办理、撤回均不庆祝。 | 实现证据；[choreography.js](../../static/choreography.js)；[app.js](../../static/app.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-092／P1 | 通知详情按标题→本人关联→关键时间→下一步→原文证据组织；正文/原文/附件/更正关系可直接定位，重要内容不藏hover。 | 保留原 noticeFocus 证据顺序；公开阶段/公示/结果入口接真实生命周期编辑器，原文证据和版本关系可达。 | 实现证据；[app.js](../../static/app.js)；[content-priority.css](../../static/system/content-priority.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-093／P1 | 手机办理面板保留固定标题/滚动内容/底部保存，压缩重复说明；错误自动定位，软键盘不遮保存，关闭可恢复草稿。 | 保留固定标题/滚动正文/保存区与服务器草稿机制；新增正式活动/办理窗口编辑；未勾选时间补丁的 required 输入禁用，避免隐藏字段阻止保存。 | 实现证据；[workflow.js](../../static/workflow.js)；[workspace-clarity.css](../../static/system/workspace-clarity.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-094／P1 | 收件表单文本/链接/附件批量回执一致；进度、失败、取消、补传明确，重试不丢已成功材料。 | 保留现有附件/文本/链接 intake 队列及失败重试、成功材料保留机制；没有用 CSS 把回执隐藏成加载装饰。 | 实现证据；[app.js](../../static/app.js)；[notice-intake.js](../../static/notice-intake.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-095／P1 | 手机聊天输入优先保留文字与发送；附件/表情/录音按频率组织；输入法、语音取消、附件恢复和短视口测试。 | 文字与发送独立占位，表情和语音进入更多菜单；录音中控制仍移动到原录音面板可停止/取消。输入法与草稿恢复逻辑保留。 | 实现证据；[chat.js](../../static/chat.js)；[chat-conversation.css](../../static/system/chat-conversation.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-096／P1 | 聊天回复工具栏不出现孤立图标行；复制/再生成/版本/分享有清晰层级，次要动作收入菜单但键盘可达。 | 复制/引用等常用动作保留，朗读/版本/重生成/分支/分享进入有标签 disclosure；Escape 返回 summary 焦点。 | 实现证据；[chat-presenter.js](../../static/genui/chat-presenter.js)；[chat-conversation.css](../../static/system/chat-conversation.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-097／P1 | AI流式正文、引用和生成界面保留滚动锚点；用户上滑时不吸回底部，停止/重试/断流状态与真实任务一致。 | 保留已存在的用户上滑/流式读写/停止/断线恢复语义；本轮没有换掉对话运行时。懒加载不改变真实 stream API。 | 实现证据；[chat-viewport.js](../../static/chat-viewport.js)；[chat.js](../../static/chat.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-098／P1 | 手机记忆页默认只留搜索、当前范围和必要筛选；高级筛选折叠，开始选择后再显示批量工具，返回保留条件。 | 高级筛选改为原生 details，搜索与当前范围保持主位；批量选择工具与原返回条件机制保留。 | 实现证据；[memory-tree.js](../../static/memory-tree.js)；[workspace-clarity.css](../../static/system/workspace-clarity.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-099／P1 | 来源卡收起后仍显示手动/自动/暂停/失败及最近成功；手机压缩不能隐藏决定收件可靠性的事实。 | 来源代理新增规则试读、应用、回滚、跨域 Feed 发布者；卡片收起仍展示真实读取状态与最近成功。该文件由来源审计代理负责验证。 | 实现证据；[sources.js](../../static/sources.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-100／P1 | 日历手机优先清楚日程列表/日/周切换，月视图拥挤有收纳；滚动、拖动、长按与官方时间修改边界明确。 | 保留手机默认 agenda 与明确日/周视图；安排新增显式 reminder_minutes，默认不提醒课程；无虚构锁屏送达保证。正式活动时段编辑走原变更确认。 | 实现证据；[calendar.js](../../static/calendar.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-101／P1 | 学院发布/成员/审计窄屏使用字段明确的行或分步表单；不能把桌面大表格简单整体缩小。 | 480px 表单单列，导航仍可横向滚动且触达 44px；批量成员前后对照、持久草稿、附件、真实受众复核、投递版本、撤回/恢复/回滚、历史参考补发均接真实 API。 | 实现证据；[campus.js](../../static/campus.js)；[workspace-clarity.css](../../static/system/workspace-clarity.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-102／P1 | 空、加载、旧内容刷新、无结果、失败、无权限、离线、已删除分别展示；每种有具体下一步和内容新鲜度。 | 分页区分加载、保留旧范围刷新、无匹配与失败；失败有重试，409 list_changed 保留筛选重新读。角色和删除结果依后端处理，不把读取失败当空列表。 | 实现证据；[paged-list.js](../../static/paged-list.js)；[library.js](../../static/library.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-103／P1 | Toast与底部导航/软键盘安全区互不遮挡；普通提示短，冲突/失败有常驻入口及核对动作，不能只要求“刷新”。 | 测量实际底部导航/聊天输入和 visualViewport，错误常驻；成功提示暂停于 hover/focus/hidden；dialog 上层可操作，异步 Undo 按真实结果反馈。 | 实现证据；[experience-system.js](../../static/experience-system.js)；[experience-system.css](../../static/experience-system.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-104／P1 | 搜索/筛选/排序/多选作用范围明确；清空一条件不清空全部，旧搜索响应不能覆盖新结果，返回恢复位置和焦点。 | 所有筛选在服务器完整集合执行；50 项分页/总匹配/加载范围明确；请求带 epoch/账号/路由守卫；返回恢复滚动及可定位焦点。重入尚未完成路由会重发新读，不永远停加载。 | 实现证据；[paged-list.js](../../static/paged-list.js)；[library.js](../../static/library.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-105／P1 | 长中文、URL、混排、附件名、姓名和学院名可读；关键日期/状态不继续缩到11px，省略内容可展开。 | 最终覆盖层关键中文字号提高到 12px，任务标题/日期不压到 11px；回复工具有文字、文件和公告正文保留展开。 | 实现证据；[workspace-clarity.css](../../static/system/workspace-clarity.css)；[chat-conversation.css](../../static/system/chat-conversation.css) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-106／P1 | 键盘、读屏、焦点返回、对话框语义、颜色对比、200%字号/缩放、中文输入法全链路验证；不只有布局不溢出。 | 新增菜单 keyboard/Escape/焦点回归，Native dialog/details/fieldset 和错误 live region；保留已有读屏名字及键盘移动。 | 实现证据／真实外部验收；[workspace-clarity.css](../../static/system/workspace-clarity.css)；[chat-presenter.js](../../static/genui/chat-presenter.js) | Actual screen reader, physical soft keyboard and browser 200% zoom not yet verified in this execution environment.；run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-107／P1 | 统一动画生命周期：减少动画、个人关闭、后台标签、离屏、卸载均停止清理；多动效不抢输入和滚动。 | 完成动画集中跟踪与取消；后台、reduced-motion、个人关闭、路由切换、账号切换清理；离屏不启动庆祝。保留现有 observer/输入响应。 | 实现证据；[choreography.js](../../static/choreography.js)；[experience-system.js](../../static/experience-system.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-108／P1 | 保持同一动作在列表/详情/搜索/跨端中的状态和文案；乐观更新失败保留上下文，实际成功后才显示成功。 | 任务提交后重读当前分页投影；草稿/发布/重试/渠道供应商接受均用实际回执语义；拒收、转交、个人跟进与最小留存回执分别标明。 | 实现证据；[app.js](../../static/app.js)；[campus.js](../../static/campus.js) | run52 实际应用浏览器门禁已通过；精确引擎范围见33槽原始清单，Agent／Composer仅Chromium，不把所有交互泛化为三引擎或真机验收。 |
| LJ-109／P1 | 严格执行209参考采用记录：序号→源码变体→依赖→交互机制→品牌适配→真实API→各状态验证→许可。35优先候选不等于全部安装。 | 209 逐项保留原编号/URL/依赖描述/适用场景/不采用理由；本轮实际打开并检查源码与交互的只有 114/115/133，采纳原生交互原则，不复制源码，不新增运行时库。 | 实现证据；[components-209.json](../sprint-2026-11-14/components-209.json)；[reference-source-review.json](../sprint-2026-11-14/reference-source-review.json) | 209 项为逐项采用审查账本；实际源码与 demo 检查只有 114／115／133，其余未实操，未全部安装。 |
| LJ-110／P2 | 深色、舒适/紧凑偏好等按需求单独确定；当前浅色为基线，不先做无完整主题体系的假开关。 | 保留浅色与珞珈绿基线，没有加入无完整配色系统的假主题开关；统一当前断点密度不等于用户可选主题／密度方案。 | 条件扩展；[tokens.css](../../static/system/tokens.css)；[responsive-density.css](../../static/system/responsive-density.css) | P2：深色及舒适／紧凑偏好需产品确认和完整可访问性验收，当前不宣称已实现。 |

### H. AI、记忆与判断可靠性：LJ-111—116

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-111／P1 | 针对时间、对象、材料、地点、前置、结果构建校园样本集；包含无时间/冲突/扫描/跨页/转述，分别报告误报、漏报与人工修订。 | [evaluate_mvp.py](../../scripts/evaluate_mvp.py)、[评测格式](../mvp-evaluation/FORMAT.md)、`test_mvp_evaluation` 已检查至少 10 开发／20 独立测试、事项家族隔离、原件／人工标准／配置哈希、不可删除失败分母、重复预测 FP 和缺结果 not_run。候选目录标记 `candidate_registry_only`，各项尚无独立人工标注且不具冻结资格。 | 实现证据／真实外部验收；[evaluate_mvp.py](../../scripts/evaluate_mvp.py)；[FORMAT.md](../mvp-evaluation/FORMAT.md)；[test_mvp_evaluation.py](../../tests/test_mvp_evaluation.py) | 工具既有，不是本轮新成果；没有真实冻结集与模型指标。历史候选 URL、HTML 解析 fixture、合成测试都不能替代人工标准。程序能核对声明格式，不能认证“人工独立”的真实性。 |
| LJ-112／P1 | 事实、推测、建议、个人意愿分开；每个重要字段可追到原文/页码，缺附件/覆盖不足时明确未知，不生成假引文。 | `notice_semantics` 对全部来源／任务进行有界复核；`deadline_evidence`、`notice_references`、`source_coverage` 区分引句、未知、缺附件；已有伪造引句、错来源、失效版本、扫描待核对测试。 | 实现证据／已执行定向验证／真实外部验收；[notice_semantics.py](../../app/notice_semantics.py)；[deadline_evidence.py](../../app/deadline_evidence.py)；[test_notice_semantics.py](../../tests/test_notice_semantics.py)；[test_evidence_acquisition.py](../../tests/test_evidence_acquisition.py) | 本轮仅把这些门槛复用到新阶段／异议窗口，并补跨年度与 Feed 证据；未改成凭模型置信度认定事实。PDF／图像真实语义准确率仍未测得。 |
| LJ-113／P1 | 原文含指令、恶意链接、提示注入时仅作为待分析材料；不能扩大工具权限、读取他人资料、自动外发或提交。 | `agent_runtime/tools.py` 的资料查询显式受 server uid／scope 控制；写文件、沙箱执行、MCP 调用经过批准与精确参数；子代理无写权限。`test_agent_runtime`／`test_agent_chat` 有越权、取消、权限收回、MCP重定向、目录穿越、重复请求与最终发布门。 | 实现证据／真实外部验收；[tools.py](../../app/agent_runtime/tools.py)；[chat.py](../../app/agent_runtime/chat.py)；[test_agent_runtime.py](../../tests/test_agent_runtime.py)；[test_agent_chat.py](../../tests/test_agent_chat.py) | 未发现本轮来源改动扩大 AI 工具权限。来源正文始终是材料，不能授权取他人资料或外发。本结论是代码边界审查，不能宣称通过所有提示注入攻防；生产 MCP／Docker 和真实模型对抗仍需环境证据。 |
| LJ-114／P1 | 分层记忆可查看来源、更新时间、适用范围、纠正/遗忘；自填和系统核实分离，旧年级/旧兴趣不永久影响判断。 | `memory_lifecycle`／`memory_policy`／`memory_reliability` 及 v3—v7 测试覆盖来源、适用域、时效、跨项目、撤回、反馈、忘记旧版本、修改后的上下文作废。 | 实现证据／真实外部验收；[memory_lifecycle.py](../../app/memory_lifecycle.py)；[memory_policy.py](../../app/memory_policy.py)；[test_memory_lifecycle_v3.py](../../tests/test_memory_lifecycle_v3.py)；[test_memory_reliability_v4.py](../../tests/test_memory_reliability_v4.py) | 本轮未重写已有记忆体系；过期／禁用／来源撤销不得作为当前依据。真实长期使用和身份变更仍需人工案例，不将自填资料升级为学校认证。 |
| LJ-115／P1 | 模型断流/超时/取消/额度耗尽/版本过时保留原件和可手工流程；重试和后台恢复不重复收费，运行状态可解释。 | `test_notice_stream`、`test_notice_budget`、`test_notice_repair`、`test_execution`、`test_agent_runtime` 覆盖流未终结、预算前置、版本变化、取消、重启标失效、保留原件、显式重试及调用记账。 | 实现证据／真实外部验收；[notice_stream.py](../../app/notice_stream.py)；[execution.py](../../app/execution.py)；[test_notice_stream.py](../../tests/test_notice_stream.py)；[test_notice_budget.py](../../tests/test_notice_budget.py) | 本轮没发付费请求，不能报告真实供应商断流成功率或账单。既有有界补正请求会记入调用量；“保留草稿与原件”不等于“远端供应商一定未计费”。 |
| LJ-116／P1 | 生成式UI沙箱、代码审查、持久状态、复制/分享、版本切换与迟到响应验证；不借生成界面绕过宿主鉴权或用户确认。 | `genui.py` 有受限表达式与数据键校验；`openui.js` 使用仅 allow-scripts 的 opaque iframe，宿主消息带实例边界；`genui_state`／`test_genui_state` 校验控件、快照、版本与所有权。前端 Node 套件含状态、恢复、复制、传输和事件检查。 | 实现证据／真实外部验收；[genui.py](../../app/genui.py)；[genui_state.py](../../app/genui_state.py)；[test_genui_state.py](../../tests/test_genui_state.py)；[test_genui_core.py](../../tests/test_genui_core.py) | 本轮前端专项另行处理集成；这里没有新浏览器实测证据。合成／源码证据不代替真实手机、读屏、完整浏览器隔离与迟到消息验收。；run52 OpenUI 三引擎及 Chromium Agent 实际通过；合成结果不替代真机、读屏和目标环境安全验收。 |

### I. 性能、运行与交付：LJ-117—128

| 编号／优先级 | 原始要求（不改写） | 已有实现与本轮深化 | 验证状态／定位 | 明确剩余条件 |
|---|---|---|---|---|
| LJ-117／P1 | F10通知/任务游标分页和轻量投影，正文/附件按需；新增/删除/筛选时不漏不重，首屏数据不随总历史线性增长。 | 新增 owner／筛选／修订绑定游标和每页最多 50 项轻量投影；正文与附件保留详情读取；新增、删除或筛选变化使旧游标明确失效。另加完整轻量工作区投影供首页／日历等，避免用首 50 条代替完整账号。 | 实现证据／已执行定向验证；[listing.py](../../app/listing.py)；[list_filters.py](../../app/list_filters.py)；[test_sprint_lists.py](../../tests/test_sprint_lists.py)；[test_workspace_projection.py](../../tests/test_workspace_projection.py) | 完整库存、原业务语义与分钟差量通过 05498ae/d55 本地双轮及 run52 两平台后端和实际分页交互；旧失败保留，未覆盖场景不据此推定通过。 |
| LJ-118／P1 | 全文索引与按字段搜索，保留正文/材料出处和权限过滤；用1万条样本对照结果正确性、P50/P95与响应体。 | FTS5 索引覆盖标题／正文等可读内容、短中文与字面标点回退，owner 过滤与事务内触发更新；记录 1 万条固定合成数据的冷／热查询及响应体。 | 实现证据／已执行定向验证；[listing.py](../../app/listing.py)；[verify_campus_capacity.py](../../scripts/verify_campus_capacity.py)；[test_sprint_lists.py](../../tests/test_sprint_lists.py) | 五个热样本的 P95 为 nearest-rank 最大值，仅为本机微基准，不代表校园并发生产性能。 |
| LJ-119／P1 | 看板/提醒共享增量投影，稳定数据与分钟时钟派生拆分；没变化时不重读重绘全列表，跨分钟必要状态仍准确。 | 新增 /api/workspace/projection：按数据库／本人／提交修订缓存完整轻量数据，时间变化仅返回 intent、tracking、推荐及任务时效差量；notice_queue 纯重算与 task_timing 复用原业务公式，草稿仅作为内部稳定依据。 | 实现证据／已执行定向验证；[workspace_projection.py](../../app/workspace_projection.py)；[notice_queue.py](../../app/notice_queue.py)；[test_workspace_projection.py](../../tests/test_workspace_projection.py)；[workspace-projection.test.mjs](../../tests/workspace-projection.test.mjs) | 投影缓存有48 MiB／24 owner／300秒边界，失效或超限重建，不能声称永久不读草稿；已有纯重算等价、隔离和实际交互的冻结证据。 |
| LJ-120／P1 | F11 CSS合并/去重、JS按路由加载、缓存和压缩验证；记录冷/热启动请求数、传输体积、解析、交互与长任务。 | 新增精确 esbuild 构建、原生路由懒加载、CSS 层合并、内容哈希资源及静态压缩；源文件变化或产物缺失回退源入口，build:check 防陈旧包。 | 实现证据；[build_frontend.mjs](../../scripts/build_frontend.mjs)；[frontend_assets.py](../../app/frontend_assets.py)；[test_frontend_bundle.py](../../tests/test_frontend_bundle.py) | run52 三引擎冷／热数据已记录，Service Worker 隔离模式明示；不能将该模式数据当生产PWA性能。标准API无法精确分离解析耗时，仍记unknown；独立真实worker安装与显式启用测试另列。 |
| LJ-121／P1 | 长列表DOM、批量选择、筛选、文件预览内存与滚动优化；虚拟化需保留键盘、读屏、定位，不仅追求帧率。 | 列表页使用有界分页和明确加载范围，批量选择遵循所选记录；没有以盲目虚拟化破坏焦点、读屏或定位；首页／日历使用完整轻量投影，原文按需加载。 | 实现证据／已执行定向验证；[paged-list.js](../../static/paged-list.js)；[library.js](../../static/library.js)；[paged-list.test.mjs](../../tests/paged-list.test.mjs)；[workspace-projection.test.mjs](../../tests/workspace-projection.test.mjs) | 投影与实际分页交互已通过冻结门禁；实体文件预览内存、长期滚动及真实辅助技术仍需设备验收。 |
| LJ-122／P1 | 数据库范围查询/索引/短事务、发布列表SQL分页；以目标活跃用户和峰值测试锁等待，达到阈值后再评估数据库迁移。 | 通知与任务 SQL 范围分页、FTS 索引、事项投影按页 ID 限定；校园发布／审计 SQL 分页与分发短事务；本轮真实本地 HTTP 压测及 1 万条合成微基准分开记录。 同库进程内写入公平准入保留读并行，等待指标包含排队、连接准备及 SQLite BEGIN；首轮历史独立本地 v3 实际绑定 05498ae/d55：5 人总等待 P95 114.149ms，10 人 272.906ms，两档均未达原 100ms；到首轮 6b15 冻结时仅两份浏览器夹具改变。 | 实现证据／已执行定向验证／真实外部验收；[listing.py](../../app/listing.py)；[notice_matters.py](../../app/notice_matters.py)；[test_sprint_lists.py](../../tests/test_sprint_lists.py)；[test_campus_sprint.py](../../tests/test_campus_sprint.py) | 学校目标活跃人数与峰值尚待确认；本机样本不能据此宣称生产容量上限或迁库阈值已实测。；首轮历史独立本地 v3 的 5/10 人总等待 P95 均未达 <100ms，不据功能通过批准试点或扩大。目标部署须实际负载复验，原门槛不放宽。 |
| LJ-123／P1 | 队列按事件增量协调、发送前复核、定期兜底；来源/模型/解析/分发各自并发和预算，避免一个慢任务拖死整站。 | 新增每 owner／channel 已提交 revision 协调：未变账户不写事务、不重算，改变立即协调、60 秒兜底；发送前仍无条件复核当前授权／期限。来源域名公平、群附件、模型分析、校园分发分别受并发与预算限制。 | 实现证据／已执行定向验证；[notification_coordination.py](../../app/notification_coordination.py)；[source_sync.py](../../app/source_sync.py)；[test_notification_coordination.py](../../tests/test_notification_coordination.py)；[test_source_fetch_contracts.py](../../tests/test_source_fetch_contracts.py) | 运行预算与队列长时恢复需结合实际部署负载验证，不把单个合成慢源用例当全站吞吐承诺。 |
| LJ-124／P1 | 从零部署、升级、数据迁移、备份恢复、回滚、磁盘满、损坏备份、重复进程、停机补偿演练；记录恢复耗时与丢失窗口。 | 保留从零部署、明确 schema 门禁、完整数据库备份和恢复；新增来源、校园、阶段、投影及观测表纳入升级／备份校验，恢复后渠道、复核授权和环境证据不会沿用。 冻结候选已记录 5/10 人备份、重启验证、恢复文件与恢复验证耗时，并逐任务 ID 比较 notice_id/status/version/data；合成快照范围内丢失为 0。 | 实现证据／已执行定向验证／真实外部验收；[db.py](../../app/db.py)；[backups.py](../../app/backups.py)；[test_workflow.py](../../tests/test_workflow.py)；[test_workflow_migration.py](../../tests/test_workflow_migration.py) | 真实生产磁盘满、部署回滚、远端损坏备份、停机恢复的 RTO／丢失窗口需在目标环境记实；本地演练只证明所测范围。；演练是在业务写入完成后快照并停止本人进程，不是断电模拟或生产 RPO；真实目标环境的磁盘、回滚与停机窗口仍需另验。 |
| LJ-125／P1 | 管理就绪与观测面板：配置存在、连接成功、真实端到端分别记录；请求ID贯穿收件/判断/任务/投递，日志脱敏。 | 就绪面板将配置存在、已记录连接成功、管理员端到端证据分开；服务端随机 request_id 关联本人通知审计与后续步骤，权限内追踪不返回私密凭据。根前端同步修正“已配置即已接通”的旧顶栏文案。 | 实现证据／真实外部验收；[observability.py](../../app/observability.py)；[operations.js](../../static/operations.js)；[test_sprint_observability.py](../../tests/test_sprint_observability.py) | 管理员手工填入的验收仍是其声明，系统不能认证真实外部设备和独立验收真实性。；后台历史事件可能没有 HTTP request_id，按本人通知／事务记录关联，不伪造统一旧链路 ID。 |
| LJ-126／P1 | F13 README、运行文档、能力表、测试口径统一；锁定版本、第三方采用登记和许可证，说明当前仓库自身许可选择。 | README／TESTING／第三方登记与构建门禁更新；新增 esbuild 仅为开发构建依赖且精确锁为 0.28.2。冻结前 pip-audit 实际检出 opentelemetry-api 1.45.1 的已知漏洞，核对官方公告后精确升级至 1.45.2；其他 Python 锁定版本保持。209 组件采用不等于批量引库。 | 实现证据；[README.md](../../README.md)；[TESTING.md](../../TESTING.md)；[test_frontend_bundle.py](../../tests/test_frontend_bundle.py) | 仓库当前未发现根 LICENSE。项目自身许可证属于所有者授权决定，本轮不得擅选；现状态须在交付说明中直说，不能称许可证已齐全。 |
| LJ-127／P1 | 实际角色三轮、真实手机、真实供应商、校园样本独立验收；CI合成结果、源码结论、真机结果各自记录，不互相替代。 | 正常链、异常恢复与权限／并发多轮工程回归分别记录；脚本、源码、模拟供应商、真实公开读取、实际应用浏览器和实体设备层级分开。 | 实现证据／真实外部验收；[audit_full_suite.py](../../scripts/audit_full_suite.py)；[run_browser_checks.py](../../scripts/run_browser_checks.py) | 实际角色三轮、真实供应商、真实手机、独立人工校园样本、累计不少于 5 天现场实践或场景验证与单位确认没有本轮完成证据。 |
| LJ-128／P1 | 制定试点容量与发布门槛：人数/日收件/高峰/设备/数据期限/支持渠道/成功率/时延/费用预算；小范围分批扩大并保留回退。 | 新增可审阅工程发布门槛：首批最多 5 人，10 人隔离样本全部达标后才建议扩大；每日每人 20 收件为工程负载档。非 AI CRUD P95<1秒、总写入等待 P95<100ms 且零失败，权限／幂等／stale 断言全过；预算未知不自动批量，保留隐私与回退契约。首轮历史 v3 的 5 人两项 P95 为282.6ms／114.149ms；10 人为743.1ms／272.906ms，两档总等待均未达标，在该首轮冻结时不批准 5 人试点或 10 人扩大。这些工程建议和样本不代表院方批准。 | 实现证据／真实外部验收；[PILOT_RELEASE_GATES.md](../PILOT_RELEASE_GATES.md)；[pilot_preflight.py](../../scripts/pilot_preflight.py)；[test_local_runtime_ownership.py](../../tests/test_local_runtime_ownership.py)；[test_model_capacity.py](../../tests/test_model_capacity.py) | 实际试点人数／日收件／峰值／设备／留存期／费用预算和可接受成功率、时延需真实院方范围；本轮样本不能代替该容量承诺。；首轮历史 v3 的 5 人试点与 10 人扩大门槛均未通过，保持 <100ms 原标准；共享 CI 单轮较快值不能替代。真实人数、负载、设备、渠道、费用负责人及预算仍待需求方确认。 |

## 5. 依赖、许可与未决扩展

新增构建开发依赖 esbuild **0.28.2** 为精确锁定；Playwright 保持 **1.62.1**，没有为 209 项展示参考批量安装组件依赖。冻结前 `pip-audit` 实际发现 `opentelemetry-api==1.45.1` 涉及 CVE-2026-126360／GHSA-mf5v-w3w3-f6cg；核对 [OpenTelemetry 官方公告](https://github.com/open-telemetry/opentelemetry-python/security/advisories/GHSA-mf5v-w3w3-f6cg) 后升级为 **1.45.2**。公告描述特定不受信 trace-context 输入造成 CPU 消耗／拒绝服务；这不证明本应用曾被利用。与基线逐行核验，其他 Python 锁定版本、`requirements-dev.txt` 及 JavaScript 运行时依赖保持。[package.json](../../package.json)、[package-lock.json](../../package-lock.json)、[requirements.lock](../../requirements.lock) 与 [THIRD_PARTY_NOTICES.md](../../THIRD_PARTY_NOTICES.md) 提供可核查依据。依赖未变；本地及已完成 run51 两平台的全范围 npm 审计（含 dev／build）为 0 已知漏洞，pip-audit strict 无已知漏洞，实际构建与重建检查已过，见 [sprint-validation.json](sprint-validation.json)。run52两平台已再次执行同范围审计并通过；已知漏洞审计不证明不存在未知漏洞。

参考组件源码实际核查的上游当前许可为 MIT + Commons Clause；本轮未复制这三项 React 源码或添加其依赖。**仓库自身根 LICENSE 当前缺失，不能替所有者擅自选择许可。** LJ-126 的运行文档和第三方登记可以完成，但项目自身许可决定不能伪称已完成。

P2 的班委／协作者最小角色、独立审核员／多学院、入站邮件、其他校方平台接口、订阅日历、送审、定时发布和深色／密度偏好均单列。已有发布分发队列不是定时公告，出站验证码邮件不是入站邮箱，ICS 下载不是 CalDAV；需要明确业务与授权条件再扩展。

## 6. 总账完整性检查

- 128 个 ID 连续且唯一，原始要求、来源行号、优先级／性质／成本全部保留；原附件 SHA-256 保留。
- 40 项来源／AI、16 项校园主责、25 项前端以及根主责／账号／条件项合并，没有省略 8 项 P2。
- JSON 的逐项实现／测试／证据、诊断历史及总账引用共 214 个仓库文件已检查存在；不将 pending 计划路径当成完成证据。
- 状态标签是证据维度，可同时出现；它们不构成完整通过率。128项逐条保留实现与验证范围；全局候选工程门禁已完成，51项外部验收与8项条件扩展仍保留，不把全局CI结果转写为128项全部实地通过。

后续更新须保留真实失败、修复、样本范围和时间。此为合并前候选冻结记录；最终main SHA与其CI以PR合并记录和Actions为准，不在本文件预先嵌入。不得删除外部条件来制造“100% 实地满足”。
